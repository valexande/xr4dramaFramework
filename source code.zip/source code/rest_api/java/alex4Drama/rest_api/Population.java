
package alex4Drama.rest_api;

import org.apache.commons.text.StringEscapeUtils;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Normalizer;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.Model;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import org.eclipse.rdf4j.model.util.Values;
import org.eclipse.rdf4j.model.vocabulary.OWL;
import org.eclipse.rdf4j.model.vocabulary.RDF;
import org.eclipse.rdf4j.model.vocabulary.RDFS;

import static org.eclipse.rdf4j.model.util.Values.iri;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import java.util.UUID;

import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

public class Population {

public static String sendGetRequestStr(String url)
    {
        try{
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            //add request header
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", "Mozilla/5.0");
            con.setRequestProperty("api_key","8t8YKQegHHl4gMCPd5TF");

            int responseCode = con.getResponseCode();

            System.out.println("Sending 'GET' request to URL : " + url);
            System.out.println("Response Code : " + responseCode);

            if(responseCode!=200 && responseCode!=201)
                return "Error code returned: "+responseCode;

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine + "\n");
            }
            in.close();
            return response.toString();
        }
        catch(IOException io){
            System.out.println(io.getMessage());
            return "IO Exception: " + io.getMessage();
        }
    }

public static Model buildStressLvl (String text) 	throws JsonSyntaxException, JsonIOException, IOException, ParseException
{
	System.out.println("we are in population");
	String uuid = UUID.randomUUID().toString().replaceAll("-", "");
	Object obj=JSONValue.parse(text);
	JSONObject jsonObj= (JSONObject) obj;

	DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS"); 
    String id= jsonObj.get("User_ID").toString();
    String lvl=jsonObj.get("Stress_Level").toString();
    float lvlf=Float.parseFloat(lvl);
    String label=" ";
    if (lvlf < 30) { label = "Low"; }
    else if (lvlf>=30 && lvlf<=70) { label = "Moderated";}
    else { label = "High";}
    String StringTime=jsonObj.get("Timestamp").toString();
    String lat=jsonObj.get("Latitude").toString();
    String log=jsonObj.get("Longitude").toString();
    String ProjectId= jsonObj.get("Project_Id").toString();
    LocalDateTime time = LocalDateTime.parse(StringTime,DATE_TIME_FORMATTER);
    
    IRI ObservationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Observation_"+uuid);
    IRI ResultInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Result_"+uuid);
    IRI FRInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "FR_"+id);
    IRI LocationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Location_"+uuid);
    
    
    ModelBuilder builder = new ModelBuilder();
    
    builder
    	.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
    	.subject(ObservationInstance)
    	  	.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
    	  	.add(RDFS.LABEL, "Observation_"+uuid)
    	  	.add(RDF.TYPE,"Xr:Observation")
    	  	.add("Xr:isConsistedIn", "Xr:project_"+ProjectId)
    	  	.add("Xr:hasTime", time)
    	  	.add("Xr:hasResult", ResultInstance)
		.subject(ResultInstance)
		  	.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
		  	.add(RDFS.LABEL, "Result_"+uuid)
		  	.add(RDF.TYPE,"Xr:Result")
		  	.add("Xr:hasStressLevel",lvlf)
		  	.add("Xr:hasResultLabel", label)
		.subject(LocationInstance)
			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			.add(RDFS.LABEL, "Location_"+uuid)
		  	.add(RDF.TYPE,"Xr:Location")
		  	.add("Xr:hasLatitude",lat )
		  	.add("Xr:hasLongitude", log)
		  	.add("Xr:hasTime", time)  
		.subject(FRInstance)
			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			.add(RDFS.LABEL, "FR_"+id)
			.add(RDF.TYPE,"Xr:FR")
			.add("Xr:included","Xr:project_"+ProjectId)
			.add("Xr:related",ResultInstance) 
			.add("Xr:hasFRLocation", LocationInstance)
			.build();
  
    return builder.build();	
 }

public static Model buildText (String text) 	throws JsonSyntaxException, JsonIOException, IOException, ParseException
{


	ModelBuilder builder = new ModelBuilder();
	
	Instant instant = Instant.now();
	DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS").withZone( ZoneId.systemDefault() );
	String formater_output = DATE_TIME_FORMATTER.format( instant );
												
	
	Object obj=JSONValue.parse(text);
	JSONObject jsonObj= (JSONObject) obj;
	JSONObject json_meta= (JSONObject) jsonObj.get("meta");
	JSONObject json_data= (JSONObject) jsonObj.get("data");
	LocalDateTime current_time=  LocalDateTime.parse(formater_output,DATE_TIME_FORMATTER);
	String id=json_meta.get("id").toString().replaceAll("-", "");
	String projectId= json_meta.get("project_id").toString();

	List<Integer> clusterIDs = new ArrayList<Integer>();
	//find project id when id is citizen
	if (projectId.equals("citizen")) {	
		try {
			   String response = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/");
	    	   String[] parts = response.split("\"id\":");
	    	   
	    	   String[] latitudeList = response.split("\"latitude\":");
	    	   String[] longitudeList = response.split("\"longitude\":");
	    	   
	    	   List<String> ids = new ArrayList<String>();
	    	   for(int j = 1; j< parts.length; j++){
	    		   ids.add(parts[j].split(",\"status\"")[0].toString());
	    		   }
	           
	    	   List<String> latitudeListFinal = new ArrayList<String>();
	    	   for(int j = 1; j < latitudeList.length; j++){
	    		   latitudeListFinal.add(latitudeList[j].split(",\"longitude\":")[0].toString());
	    		   }
	    	   
	    	   List<String> longitudeListFinal = new ArrayList<String>();
	    	   for(int j = 1; j < longitudeList.length; j++){
	    		   longitudeListFinal.add(longitudeList[j].split("},\"")[0].toString());
	    		   }
	    	   
	    	   
	    	      	   
	    	   //create json for new pois
	    	   
	    	   JSONObject objHelper = (JSONObject) json_meta.get("location");
	    	   JSONArray objHelperMid=(JSONArray) objHelper.get("coordinates");
	    	   double latitude = Double.parseDouble(objHelperMid.get(0).toString());
	    	   double longitude = Double.parseDouble(objHelperMid.get(1).toString());


	           //end here code for new pois json
	           
	           //procedure to find project ids
	    	   List<Double> longitudeSE = new ArrayList<Double>();
	    	   for(int j = 1; j < longitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(longitudeListFinal.get(j));
	    		   longitudeSE.add(helper);
	    		   }
	    	   
	    	   List<Double> longitudeNW = new ArrayList<Double>();
	    	   for(int j = 0; j < longitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(longitudeListFinal.get(j));
	    		   longitudeNW.add(helper);
	    		   }
	    	   
	    	   List<Double> latitudeSE = new ArrayList<Double>();
	    	   for(int j = 1; j < latitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(latitudeListFinal.get(j));
	    		   latitudeSE.add(helper);
	    		   }
	    	   
	    	   List<Double> latitudeNW = new ArrayList<Double>();
	    	   for(int j = 0; j < latitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(latitudeListFinal.get(j));
	    		   latitudeNW.add(helper);
	    		   } 
	    	  
	    	   for(int j = 0; j < longitudeSE.size(); j++) {
	    		   double nwLat = 0;
	    		   double seLat = 0;
	    		   double nwLon = 0;
	    		   double seLon = 0;
	    		   nwLat = latitudeNW.get(j);
	    		   seLat = latitudeSE.get(j);
	    		   nwLon = longitudeNW.get(j);
	    		   seLon = longitudeSE.get(j);

	    		   if( seLat <= latitude && latitude <= nwLat && nwLon <= longitude && longitude <= seLon ) {
	    			   clusterIDs.add(Integer.valueOf(ids.get(j)));
	    			}
	    	   }
		}
		catch(Exception e){
	        System.err.println(e.getCause());}
	}
	else {
		
		clusterIDs.add(Integer.valueOf(projectId));
	}
	//end here
	
	System.out.println("Project ids: " + clusterIDs);
	String type= json_data.get("type").toString();
	
	
	String uuid = UUID.randomUUID().toString().replaceAll("-", "");

	IRI ObservationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Observation_"+uuid);
	IRI LocationInstance = null;
	IRI InfoOfIntInstance = null;
	for (int p = 0; p < clusterIDs.size(); p++) {
		projectId = clusterIDs.get(p).toString();
	if(type.equals("incident")) {
	String category = json_data.get("category").toString();
	String subCategory = json_data.get("subcategory").toString();
	JSONArray tagsArray = (JSONArray) json_data.get("tags");
	
	JSONArray objJASON_Array=(JSONArray) json_data.get("situations");
	
	builder
 	.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
 		.subject(ObservationInstance)
	 	.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
	  	.add(RDFS.LABEL, "Observation_"+uuid)
	  	.add("Xr:isRelatedWithSimmo", json_meta.get("id").toString())
	  	.add(RDF.TYPE,"Xr:Observation")
	  	.add("Xr:hasObservationType", type)
	  	.add("Xr:hasCurrentTime", current_time)
	  	.add("Xr:hasCategory", category)
	  	.add("Xr:hasSubCategory", subCategory)
	  	.add("Xr:isConsistedIn", "Xr:project_"+projectId);
	for (int i = 0; i < tagsArray.size(); i++) {
		builder
	 	.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
	 		.subject(ObservationInstance)
	 		.add("Xr:hasTag", tagsArray.get(i).toString());
	}
	
	if(json_meta.containsKey("entity")) {
		String entity= json_meta.get("entity").toString();
		builder
	 	.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
	 		.subject(ObservationInstance)
		  	.add("Xr:comesFromEntity", entity);
	}
	 uuid = UUID.randomUUID().toString().replaceAll("-", "");
	 
	 
	for (int i = 0; i < objJASON_Array.size(); i++) {
		
		JSONObject json_sit=(JSONObject)objJASON_Array.get(i);
		
		if (json_sit.containsKey("location") ) { 
			String locationURI=json_sit.get("location").toString();
			uuid = UUID.randomUUID().toString().replaceAll("-", "");

			if (locationURI !=null ) {  	
			
			 LocationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Location_"+uuid); 
			
			builder
			.subject(LocationInstance)
				.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
				.add(RDFS.LABEL, "Location_"+uuid)
			  	.add(RDF.TYPE,"Xr:Location")
			  	.add("Xr:hasURI", locationURI);
			
			
			
			if(json_sit.containsKey("location") && json_sit.containsKey("coordinates") ) {
				
				
				String coordinates=json_sit.get("coordinates").toString();
				String parts[] = coordinates.split("(?<= N)");
				String latitude= parts[0];
				String longtitude= parts[1];

				if(latitude !=null && longtitude!= null) {
					builder
					.subject(LocationInstance)
					  	.add("Xr:hasLatitude",latitude )
					  	.add("Xr:hasLongitude", longtitude);
				}
			}
			}
		}
		
		
		uuid = UUID.randomUUID().toString().replaceAll("-", "");
		IRI ResultInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Result_"+uuid);
		builder
		
		.subject(ResultInstance)
		  	.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
		  	.add(RDFS.LABEL, "TextualMetadata_"+uuid)
		  	.add(RDF.TYPE,"Xr:TextualMetadata")
		  	.add("Xr:hasLabel", json_sit.get("label").toString());
		
		
		
		if (json_sit.containsKey("risk_level")) {
			String risk_lvl=json_sit.get("risk_level").toString();
		
			builder
			.subject(ResultInstance)	
			  	.add("Xr:hasTextualRiskLabel", risk_lvl);
		}
		
	
		JSONArray agentJson=(JSONArray) json_sit.get("agents");
		
		for (int ag = 0; ag < agentJson.size(); ag++) {
			builder
		 	.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
		 		.subject(ResultInstance)
		 		.add("Xr:hasAgent", agentJson.get(ag).toString());
		}

		
		
		
		if ((json_sit.get("affected_objects"))!=null) { 	
			
		JSONArray objJASON_Array_2=(JSONArray) json_sit.get("affected_objects");
		for (int j = 0; j < objJASON_Array_2.size(); j++) {
			
			 
			InfoOfIntInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "InformationOfInterest"+ uuid +"_"+ j); 
			

			JSONObject object = (JSONObject) objJASON_Array_2.get(j);
			
			
			builder
			.subject(InfoOfIntInstance)
				.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
		  		
				.add(RDFS.LABEL, "InformationOfInterest"+ uuid +"_"+ j)
		  		.add(RDF.TYPE,"Xr:InformationOfInterest")
				.add("Xr:hasType", object.get("name"))
				.add("Xr:hasQuantity", object.get("quantity"))
				.add("Xr:featureOf",ObservationInstance)
				.add("Xr:hasTextualMetadata", ResultInstance);
			
			if (LocationInstance != null) { 
			
			builder
			.subject(InfoOfIntInstance)
				.add("Xr:hasLocation",LocationInstance);
			}
			
		}
		
		if(objJASON_Array_2.size()==0) {
			uuid = UUID.randomUUID().toString().replaceAll("-", "");
			 InfoOfIntInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "InformationOfInterest"+ uuid);
				
				
				
				builder
				.subject(InfoOfIntInstance)
					.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			  		.add(RDFS.LABEL, "InformationOfInterest"+ uuid)
			  		.add(RDF.TYPE,"Xr:InformationOfInterest")
					.add("Xr:featureOf",ObservationInstance)
					.add("Xr:hasTextualMetadata", ResultInstance);
				
				if (LocationInstance != null) { 
				
				builder
				.subject(InfoOfIntInstance)
					.add("Xr:hasLocation",LocationInstance);
				}	
		}
		}
		
		
		
	}
	}
	else if	(type.equals("logistics")){
		String category = json_data.get("category_name").toString();

		JSONArray objJASON_Array=(JSONArray) json_data.get("utilities");
		JSONArray coordinates=(JSONArray) json_data.get("coordinates");
		builder
	 	.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
	 		.subject(ObservationInstance)
		 	.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
		  	.add(RDFS.LABEL, "Observation_"+uuid)
		  	.add("Xr:isRelatedWithSimmo", json_meta.get("id").toString())
		  	.add(RDF.TYPE,"xR:#Observation")
		  	.add("Xr:hasObservationType", type)
		  	.add("Xr:hasCurrentTime", current_time)
		  	.add("Xr:hasCategory", category)
		  	.add("Xr:isConsistedIn", "Xr:project_"+projectId);	
		
		for (int i = 0; i < objJASON_Array.size(); i++) {
			
			
			
			uuid = UUID.randomUUID().toString().replaceAll("-", "");
			JSONObject object = (JSONObject) objJASON_Array.get(i);
			
		 	LocationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Location_"+uuid); 
			
		 	builder
		 	.subject(LocationInstance)
			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			.add(RDFS.LABEL, "Location_"+uuid)
		  	.add(RDF.TYPE,"Xr:Location")
		  	.add("Xr:hasLatitude", coordinates.get(0))
		  	.add("Xr:hasLongitude", coordinates.get(1))
		  	.add("Xr:hasReference", object.get("location"));
			
			InfoOfIntInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "InformationOfInterest"+ uuid +"_"+ i);
			builder
			.subject(InfoOfIntInstance)
				.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
		  		
				.add(RDFS.LABEL, "InformationOfInterest"+ uuid +"_"+ i)
		  		.add(RDF.TYPE,"Xr:InformationOfInterest")
				.add("Xr:hasType", object.get("type"))
				.add("Xr:hasQuantity", object.get("quantity"))
				.add("Xr:featureOf",ObservationInstance)
				.add("Xr:hasLocation", LocationInstance);
			
			
		 	
		}//closes the for loop

		
	}//closes the else condition
	 String responseEmergency = mapEmergencyGeneral(projectId);
	 System.out.println("All set for project id: " + projectId);
	}
	 return builder.build();	
   
	
}

public static Model buildVisuals (String text) 	throws JsonSyntaxException, JsonIOException, IOException, ParseException
{
	System.out.println("we are in population");
	String uuid = UUID.randomUUID().toString().replaceAll("-", "");
	
	Instant instant = Instant.now();
	DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS").withZone( ZoneId.systemDefault() );
	String formater_output = DATE_TIME_FORMATTER.format( instant );
	LocalDateTime current_time=  LocalDateTime.parse(formater_output,DATE_TIME_FORMATTER);
	
	Object obj=JSONValue.parse(text);
	JSONObject jsonObj= (JSONObject) obj;
	JSONObject json_header= (JSONObject) jsonObj.get("header");
	
	String StringTime=json_header.get("timestamp").toString();
	LocalDateTime time = LocalDateTime.parse(StringTime,DATE_TIME_FORMATTER);
	String simmoid= json_header.get("simmoid").toString();
	String projectId= json_header.get("project_id").toString();
	
	List<Integer> clusterIDs = new ArrayList<Integer>();
	//find project id when id is citizen
	if (projectId.equals("citizen")) {	
		try {
			   String response = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/");
	    	   String[] parts = response.split("\"id\":");
	    	   
	    	   String[] latitudeList = response.split("\"latitude\":");
	    	   String[] longitudeList = response.split("\"longitude\":");
	    	   
	    	   List<String> ids = new ArrayList<String>();
	    	   for(int j = 1; j< parts.length; j++){
	    		   ids.add(parts[j].split(",\"status\"")[0].toString());
	    		   }
	           
	    	   List<String> latitudeListFinal = new ArrayList<String>();
	    	   for(int j = 1; j < latitudeList.length; j++){
	    		   latitudeListFinal.add(latitudeList[j].split(",\"longitude\":")[0].toString());
	    		   }
	    	   
	    	   List<String> longitudeListFinal = new ArrayList<String>();
	    	   for(int j = 1; j < longitudeList.length; j++){
	    		   longitudeListFinal.add(longitudeList[j].split("},\"")[0].toString());
	    		   }
	    	   
	    	   
	    	      	   
	    	   //create json for new pois
	    	   JSONArray objHelper=(JSONArray) jsonObj.get("shotInfo");
	    	   JSONObject firstShot = (JSONObject) objHelper.get(0);
	    	   JSONArray coordinateHelper=(JSONArray) firstShot.get("coordinate");
	    	   double latitude = Double.parseDouble(coordinateHelper.get(0).toString());
	    	   double longitude = Double.parseDouble(coordinateHelper.get(1).toString());

	           //end here code for new pois json
	           
	           //procedure to find project ids
	    	   List<Double> longitudeSE = new ArrayList<Double>();
	    	   for(int j = 1; j < longitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(longitudeListFinal.get(j));
	    		   longitudeSE.add(helper);
	    		   }
	    	   
	    	   List<Double> longitudeNW = new ArrayList<Double>();
	    	   for(int j = 0; j < longitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(longitudeListFinal.get(j));
	    		   longitudeNW.add(helper);
	    		   }
	    	   
	    	   List<Double> latitudeSE = new ArrayList<Double>();
	    	   for(int j = 1; j < latitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(latitudeListFinal.get(j));
	    		   latitudeSE.add(helper);
	    		   }
	    	   
	    	   List<Double> latitudeNW = new ArrayList<Double>();
	    	   for(int j = 0; j < latitudeListFinal.size();  j = j + 2){
	    		   double helper = 0;
	    		   helper = Float.valueOf(latitudeListFinal.get(j));
	    		   latitudeNW.add(helper);
	    		   } 
	    	  
	    	   for(int j = 0; j < longitudeSE.size(); j++) {
	    		   double nwLat = 0;
	    		   double seLat = 0;
	    		   double nwLon = 0;
	    		   double seLon = 0;
	    		   nwLat = latitudeNW.get(j);
	    		   seLat = latitudeSE.get(j);
	    		   nwLon = longitudeNW.get(j);
	    		   seLon = longitudeSE.get(j);

	    		   if( seLat <= latitude && latitude <= nwLat && nwLon <= longitude && longitude <= seLon ) {
	    			   clusterIDs.add(Integer.valueOf(ids.get(j)));
	    			}
	    	   }
		}
		catch(Exception e){
	        System.err.println(e.getCause());}
	}
	else {
		clusterIDs.add(Integer.valueOf(projectId));
	}
	//end here
	System.out.println("Project ids: " + clusterIDs);
	
	ModelBuilder builder = new ModelBuilder();
	IRI ObservationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Observation_"+uuid);
	
	for (int p = 0; p < clusterIDs.size(); p++) {
		projectId = clusterIDs.get(p).toString();
	builder
	.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
	.subject(ObservationInstance)
  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
  		.add(RDFS.LABEL, "Observation_"+uuid)
  		.add(RDF.TYPE,"Xr:Observation")
  		.add("Xr:isConsistedIn", "Xr:project_"+projectId)
  		.add("Xr:hasTime", time)
  		.add("Xr:hasCurrentTime", current_time);
  		
	
	if(json_header.get("entity").equals("video")) { 
		IRI VideoInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Video_"+uuid);
		builder
		.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
		.subject(ObservationInstance)
			.add("Xr:hasMultimedia", VideoInstance)
			.subject(VideoInstance)
	  			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
	  			.add(RDFS.LABEL, "Video_"+uuid)
	  			.add(RDF.TYPE,"Xr:Video")
	  			.add("Xr:hasSIMMORef", simmoid);
	}
	else if(json_header.get("entity").equals("image")) { 
		IRI ImageInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "Image_"+uuid);
		builder
		.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
		.subject(ObservationInstance)
			.add("Xr:hasMultimedia", ImageInstance)
			.subject(ImageInstance)
	  			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
	  			.add(RDFS.LABEL, "Image_"+uuid)
	  			.add(RDF.TYPE,"Xr:Image")
	  			.add("Xr:hasSIMMORef", simmoid);
	}
	else if(json_header.get("entity").equals("twitter_post")) { 
		IRI TwitterPostInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "TwitterPost_"+uuid);
		builder
		.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
		.subject(ObservationInstance)
			.add("Xr:hasMultimedia", TwitterPostInstance)
			.subject(TwitterPostInstance)
	  			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
	  			.add(RDFS.LABEL, "TwitterPost_"+uuid)
	  			.add(RDF.TYPE,"Xr:TwitterPost")
	  			.add("Xr:hasSIMMORef", simmoid);
	}
	
	JSONArray objJASON_Array=(JSONArray) jsonObj.get("shotInfo");
	for (int i = 0; i < objJASON_Array.size(); i++) {
		
		IRI VisualMetaInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "VisualMetadata_"+ uuid +"_"+ i);
		
		JSONObject json_shot=(JSONObject)objJASON_Array.get(i);
		
		String fShotId= json_shot.get("shotIdx").toString();
		int shotId= Integer.parseInt(fShotId);
		
		String sStartFrame= json_shot.get("startFrame").toString();
		int startFrame= Integer.parseInt(sStartFrame);
		String sEndFrame= json_shot.get("endFrame").toString();
		int endFrame= Integer.parseInt(sEndFrame);
		
		String fanimal = json_shot.get("animalsInDanger").toString();//new code
		int animal = Integer.parseInt(fanimal);//new code
		String fPeople= json_shot.get("peopleInDanger").toString();
		int people= Integer.parseInt(fPeople);
		String fVehicles= json_shot.get("vehiclesInDanger").toString();
		int vehicles= Integer.parseInt(fVehicles);
		String fRiver= json_shot.get("riverOvertop").toString();
		boolean river=Boolean.parseBoolean(fRiver);
		String area= json_shot.get("area").toString();
		String fAreaProb= json_shot.get("areaProb").toString();
		float areaProb = 0; if ( fAreaProb == "none") { areaProb = 0;}  else {  areaProb= Float.parseFloat(fAreaProb);}
		String fOutdoor= json_shot.get("outdoor").toString();
		boolean outdoor=Boolean.parseBoolean(fOutdoor);
		String emergency= json_shot.get("emergencyType").toString();
		String fEmergProb= json_shot.get("emergencyProb").toString();
		float emergencyProb= Float.parseFloat(fEmergProb);
		uuid = UUID.randomUUID().toString().replaceAll("-", "");
		String category = json_shot.get("category").toString();
		String subcategory = json_shot.get("subcategory").toString();
		
		builder
		.subject(VisualMetaInstance)
			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
	  		.add(RDFS.LABEL, "VisualMetadata_"+ uuid +"_"+ i) 
			
	  		.add(RDF.TYPE,"Xr:VisualMetadata")
	  		.add("Xr:hasShotId",shotId)
	  		.add("Xr:hasStartFrame",startFrame)
	  		.add("Xr:hasEndFrame",endFrame)
	  		.add("Xr:peopleInDanger", people)
	  		.add("Xr:animalInDanger", animal)// new code
	  		.add("Xr:vehicleInDanger", vehicles)
	  		.add("Xr:hasRiverOvertop", river)
	  		.add("Xr:hasArea", area)
	  		.add("Xr:hasAreaProb", areaProb)
	  		.add("Xr:isOutdoor", outdoor)
	  		.add("Xr:hasCategory", category)
	  		.add("Xr:hasSubCategory", subcategory)
	  		.add("Xr:hasEmergencyProb", emergencyProb)
	  		.add("Xr:hasEmergency",emergency)
	  	.subject(ObservationInstance)
	  		.add("Xr:hasMetadata", "VisualMetadata_"+ uuid +"_"+ i);
		
		
		//some new code for visuals//
		if ((json_shot.get("infraInDanger"))!=null) {
			JSONArray jsonInfra =(JSONArray) json_shot.get("infraInDanger");
			
			for (int j = 0; j < jsonInfra.size(); j++) {
				
				String infra = jsonInfra.get(j).toString();
				builder
				.subject(VisualMetaInstance)
				.add("Xr:infraInDanger", infra);
			}
		}
		
		// the new code ends here //
		
		//some new code for visuals//
		if ((json_shot.get("objectsInDanger"))!=null) {
			JSONArray jsonObject =(JSONArray) json_shot.get("objectsInDanger");
			
			for (int j = 0; j < jsonObject.size(); j++) {
				
				String object = jsonObject.get(j).toString();
				builder
				.subject(VisualMetaInstance)
				.add("Xr:objectInDanger", object);
			}
		}
		
		// the new code ends here //
	  	
		if ((json_shot.get("objectsFound"))!=null) {
			
			
		JSONArray objJASON_Array_2=(JSONArray) json_shot.get("objectsFound");
		
		
		for (int j = 0; j < objJASON_Array_2.size(); j++) {
			
			IRI InfoOfIntInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "InformationOfInterest"+ uuid +"_"+ i+"_"+j); 
			
			JSONObject json_objects=(JSONObject)objJASON_Array_2.get(j);
			
			String type= json_objects.get("type").toString();
			String fObjectProb= json_objects.get("probability").toString();
			float ObjectProb= Float.parseFloat(fObjectProb);
			
			builder
			.subject(InfoOfIntInstance)
			.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
	  		.add(RDFS.LABEL, "InformationOfInterest"+ uuid +"_"+ i+"_"+j) 
			
	  		.add(RDF.TYPE,"Xr:InformationOfInterest")
			.add("Xr:hasType", type)
			.add("Xr:hasProbability", ObjectProb)
			.add("Xr:featureOfMetaInstance",VisualMetaInstance); 
		}
		}
	}
	String responseEmergency = mapEmergencyGeneral(projectId);
	System.out.println("All set for project id: " + projectId);
	}
	return builder.build();
	
}		
	
public static String mapEmergencyGeneral(String projectID) {
	System.out.println("This is the project id: " + projectID);
	
	try {
		String response = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/");
	   String[] parts = response.split("\"id\":");
	   String[] cities = response.split("\"city\":");
	   String[] countries = response.split("\"country\":");
	   List<String> ids = new ArrayList<String>();
	   List<String> city = new ArrayList<String>();
	   List<String> country = new ArrayList<String>();
	   for(int j = 1; j< parts.length; j++){
		   ids.add(parts[j].split(",\"status\"")[0].toString());
		   city.add(cities[j].split(",\"country\"")[0].toString());
		   country.add(countries[j].split(",\"description\"")[0].toString());
		   }
	   
	  List<String> desiredProject = new ArrayList<String>();
	  for (int j = 1; j<ids.size(); j++) {
		  if (ids.get(j).equals(projectID)) {
			  
				ModelBuilder builder = new ModelBuilder();
				IRI ProjectInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "project_" + ids.get(j));
				builder
				.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
				.subject(ProjectInstance)
			  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			  		.add(RDFS.LABEL, "project_"+ ids.get(j))
			  		.add(RDF.TYPE,"Xr:Project")
			  		.add("Xr:hasGeneralInfo", "Xr:general" + city.get(j).replace("\"", "").replace(" ", "_"))
			  		.add("Xr:hasEmergencyNumber", "Xr:emergeny" + country.get(j).replace("\"", "").replace(" ", "_"));
				GraphDB.add2(builder.build());
				
				String responseWikipedia = sendGetRequestStr("https://www.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro=&explaintext=&titles=" + city.get(j).replace("\"", "").replace(" ", "_"));
				String Description = "";
				String url = "";
				if (responseWikipedia.contains("-1")) {
					 Description = "Wikipedia could not return description for " + city.get(j).replace("\"", "").replace(" ", "_") + " please try only the name of the city";
					 url = "Wikipedia could not return url for " + city.get(j).replace("\"", "").replace(" ", "_") + " please try only the name of the city";
				}
				else{
					Gson gson = new Gson();
					//String normalized_string = Normalizer.normalize(responseWikipedia, Normalizer.Form.NFD);
					String resultString = responseWikipedia.split("\"extract\":")[1].toString().replace("}}}}", "");;
					Description = "StringEscapeUtils.unescapeJava(sJava):\n" + StringEscapeUtils.unescapeJava(resultString);

					url = "https://en.wikipedia.org/wiki/" + city.get(j).replace("\"", "");
				}
				Object emergency=JSONValue.parse("{\"Algeria\" :{\"police\": \"1548\",\"ambulance\": \"14\",\"fire\": \"14\"},\"Angola\":{\"police\": \"113\",\"ambulance\": \"112/116\",\"fire\": \"115\"},	\"Ascension Island\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Benin\":{\"police\": \"117\",\"ambulance\": \"112\",\"fire\": \"118\"},\"Botswana\":{\"police\": \"999\",\"ambulance\": \"997\",\"fire\": \"998\"},\"Burkina Faso\":{\"police\": \"17\",\"ambulance\": \"112\",\"fire\": \"18\"},\"Cameroon\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"111\"},\"Cape Verde\":{\"police\": \"132\",\"ambulance\": \"130\",\"fire\": \"131\"},\"Central African Republic\":{\"police\": \"117\",\"ambulance\": \"1220\",\"fire\": \"118\"},\"Chad\":{\"police\": \"17\",\"ambulance\": \"2551-4242\",\"fire\": \"18\"},\"Comoros\":{\"police\": \"17\",\"ambulance\": \"772-03-73\",\"fire\": \"18\"},\"Republic of Congo\":{\"police\": \"117\",\"ambulance\": \"None\",\"fire\": \"118\"},\"Democratic Republic of Congo\":{\"police\": \"112\",\"ambulance\": \"\",\"fire\": \"118\"},\"Djibouti\":{\"police\": \"17\",\"ambulance\": \"19\",\"fire\": \"18\"},\"Egypt\":{\"police\": \"122\",\"ambulance\": \"123\",\"fire\": \"180\"},\"Equatorial Guinea\":{\"police\": \"114\",\"ambulance\": \"115\",\"fire\": \"112\"},\"Eritrea\":{\"police\": \"113\",\"ambulance\": \"114\",\"fire\": \"116\"},\"Eswatini\":{\"police\": \"999\",\"ambulance\": \"977\",\"fire\": \"933\"},\"Ethiopia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Gabon\":{\"police\": \"1730\",\"ambulance\": \"1300\",\"fire\": \"18\"},\"Gambia\":{\"police\": \"117\",\"ambulance\": \"116\",\"fire\": \"118\"},\"Ghana\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guinea\":{\"police\": \"117\",\"ambulance\": \"18\",\"fire\": \"442-020\"},\"Guinea-Bissau\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Ivory Coast\":{\"police\": \"110 or 111 or 170\",\"ambulance\": \"185\",\"fire\": \"180\"},\"Liberia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Kenya\":{\"police\": \"112 or 999 or 911\",\"ambulance\": \"112 or 999 or 911\",\"fire\": \"112 or 999 or 911\"},\"Libya\":{\"police\": \"1515\",\"ambulance\": \"1515\",\"fire\": \"1515\"},\"Lesotho\":{\"police\": \"123\",\"ambulance\": \"121\",\"fire\": \"122\"},\"Madagascar\":{\"police\": \"117\",\"ambulance\": \"124\",\"fire\": \"118\"},\"Malawi\":{\"police\": \"997\",\"ambulance\": \"998\",\"fire\": \"999\"},\"Mali\":{\"police\": \"17\",\"ambulance\": \"15\",\"fire\": \"18\"},\"Mauritius\":{\"police\": \"112\",\"ambulance\": \"114\",\"fire\": \"115\"},\"Mauritania\":{\"police\": \"117\",\"ambulance\": \"101\",\"fire\": \"118\"},\"Mayotte\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Morocco\":{\"police\": \"19\",\"ambulance\": \"15\",\"fire\": \"15\"},\"Mozambique\":{\"police\": \"119\",\"ambulance\": \"117\",\"fire\": \"198\"},\"Nambia\":{\"police\": \"10111\",\"ambulance\": \"depeding on town/city\",\"fire\": \"depending on town/city\"},\"Nigeria\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Niger\":{\"police\": \"17\",\"ambulance\": \"15\",\"fire\": \"18\"},\"Reunion\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Rwanda\":{\"police\": \"112\",\"ambulance\": \"912\",\"fire\": \"112\"},\"Saint Helena\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Sao Tome and Principe\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Senegal\":{\"police\": \"17\",\"ambulance\": \"18\",\"fire\": \"1515\"},\"Seychelles\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Sierra Leone\":{\"police\": \"019\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Somalia\":{\"police\": \"888\",\"ambulance\": \"999\",\"fire\": \"555\"},\"South Africa\":{\"police\": \"10111\",\"ambulance\": \"10117\",\"fire\": \"10117\"},\"Sudan\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"South Sudan\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Tanzania\":{\"police\": \"112\",\"ambulance\": \"114\",\"fire\": \"115\"},\"Togo\":{\"police\": \"117\",\"ambulance\": \"8200\",\"fire\": \"118\"},\"Tristan da Cuhna\":{\"police\": \"999\",\"ambulance\": \"911\",\"fire\": \"999\"},\"Tunisia\":{\"police\": \"197\",\"ambulance\": \"190\",\"fire\": \"198\"},\"Uganda\":{\"police\": \"112\",\"ambulance\": \"911\",\"fire\": \"112\"},\"Western Sahara\":{\"police\": \"150\",\"ambulance\": \"150\",\"fire\": \"150\"},\"Zambia\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Zimbabwe\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Antarctica\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Afghanistan\":{\"police\": \"119\",\"ambulance\": \"112\",\"fire\": \"119\"},\"Bahrain\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Bangladesh\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Bhutan\":{\"police\": \"113\",\"ambulance\": \"112\",\"fire\": \"110\"},\"British Indian Ocean Territory\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Brunei\":{\"police\": \"993\",\"ambulance\": \"991\",\"fire\": \"995\"},\"Myanmar\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Cambodia\":{\"police\": \"117\",\"ambulance\": \"119\",\"fire\": \"118\"},\"Peoples Republic of China\":{\"police\": \"110\",\"ambulance\": \"120\",\"fire\": \"119\"},\"Christmas Island\":{\"police\": \"000\",\"ambulance\": \"000\",\"fire\": \"000\"},\"Cocos Islands\":{\"police\": \"000\",\"ambulance\": \"000\",\"fire\": \"000\"},\"East Timor\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Hong Kong\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"India\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Indonesia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Iran\":{\"police\": \"110\",\"ambulance\": \"115\",\"fire\": \"125\"},\"Iraq\":{\"police\": \"112 or 911\",\"ambulance\": \"112 or 911\",\"fire\": \"112 or 911\"},\"Israel\":{\"police\": \"100\",\"ambulance\": \"101\",\"fire\": \"102\"},\"Japan\":{\"police\": \"110\",\"ambulance\": \"119\",\"fire\": \"119\"},\"Jordan\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Kazakhstan\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Kyrgyzstan\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"Democratic People's Republic of Korea\":{\"police\": \"local numbers only\",\"ambulance\": \"local numbers only\",\"fire\": \"8119\"},\"Republic of Korea\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"119\"},\"Kuwait\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Laos\":{\"police\": \"191\",\"ambulance\": \"195\",\"fire\": \"190\"},\"Lebanon\":{\"police\": \"999 or 112\",\"ambulance\": \"140\",\"fire\": \"175\"},\"Macau\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Maldives\":{\"police\": \"119\",\"ambulance\": \"102\",\"fire\": \"118\"},\"Malaysia\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"994\"},\"Mongolia\":{\"police\": \"105\",\"ambulance\": \"105\",\"fire\": \"105\"},\"Nepal\":{\"police\": \"100\",\"ambulance\": \"102\",\"fire\": \"101\"},\"Oman\":{\"police\": \"9999\",\"ambulance\": \"9999\",\"fire\": \"9999\"},\"Pakistan\":{\"police\": \"115\",\"ambulance\": \"115 and 1122\",\"fire\": \"16\"},\"Philippines\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Qatar\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Saudi Arabia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Singapore\":{\"police\": \"999\",\"ambulance\": \"995\",\"fire\": \"995\"},\"Sri Lanka\":{\"police\": \"119\",\"ambulance\": \"110\",\"fire\": \"110\"},\"Syria\":{\"police\": \"112\",\"ambulance\": \"110\",\"fire\": \"113\"},\"Republic of Chine (Taiwan)\":{\"police\": \"110\",\"ambulance\": \"119\",\"fire\": \"119\"},\"Tajikistan\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Thailand\":{\"police\": \"191 or 911\",\"ambulance\": \"1669\",\"fire\": \"199\"},\"Turkmenistan\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"United Arab Emirates\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Uzbekistan\":{\"police\": \"102\",\"ambulance\": \"101\",\"fire\": \"103\"},\"Vietnam\":{\"police\": \"113\",\"ambulance\": \"115\",\"fire\": \"114\"},\"Yemen\":{\"police\": \"194\",\"ambulance\": \"191\",\"fire\": \"191\"},\"Akrotiri and Dhekelia\":{\"police\": \"112\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Aland Islands\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Albania\":{\"police\": \"129\",\"ambulance\": \"127\",\"fire\": \"128\"},\"Andorra\":{\"police\": \"110\",\"ambulance\": \"116\",\"fire\": \"118\"},\"Armenia\":{\"police\": \"112 or 911\",\"ambulance\": \"112 or 911\",\"fire\": \"112 or 911\"},\"Austria\":{\"police\": \"112 or 133\",\"ambulance\": \"144\",\"fire\": \"122\"},\"Azerbaijan\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"Belarus\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"Belgium\":{\"police\": \"101 or 112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Bosnia and Herzegovina\":{\"police\": \"122\",\"ambulance\": \"124\",\"fire\": \"123\"},\"Bulgaria\":{\"police\": \"112 or 166\",\"ambulance\": \"112 or 150\",\"fire\": \"112 or 160\"},\"Croatia\":{\"police\": \"112 or 192\",\"ambulance\": \"999 or 194\",\"fire\": \"999 or 193\"},\"Cyprus\":{\"police\": \"112 or 199\",\"ambulance\": \"999 or 199\",\"fire\": \"999 or 199\"},\"Czech Republic\":{\"police\": \"112 or 158\",\"ambulance\": \"112 or 155\",\"fire\": \"112 or 150\"},\"Denmark\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Estonia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Faroe Islands\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Finland\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"France\":{\"police\": \"112 or 17\",\"ambulance\": \"112 or 15\",\"fire\": \"112 or 18\"},\"Georgia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Germany\":{\"police\": \"110\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Gibraltar\":{\"police\": \"199 or 112 or 999\",\"ambulance\": \"190 or 112 or 999\",\"fire\": \"190 or 112 or 999\"},\"Greece\":{\"police\": \"100\",\"ambulance\": \"166\",\"fire\": \"199\"},\"Greenland\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guemsey\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Hungary\":{\"police\": \"112 or 107\",\"ambulance\": \"112 or 104\",\"fire\": \"112 or 105\"},\"Iceland\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Ireland\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Isle of Man\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Italy\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Jersey\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Kosovo\":{\"police\": \"192\",\"ambulance\": \"194\",\"fire\": \"193\"},\"Latvia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Lithuania\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Liechtenstein\":{\"police\": \"117\",\"ambulance\": \"144\",\"fire\": \"118\"},\"Luxembourg\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Malta\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Moldova\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Monaco\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Monaco\":{\"police\": \"17\",\"ambulance\": \"15\",\"fire\": \"18\"},\"Montenegro\":{\"police\": \"122\",\"ambulance\": \"124\",\"fire\": \"123\"},\"Netherlands\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"North Macedonia\":{\"police\": \"192 or 112\",\"ambulance\": \"194 or 112\",\"fire\": \"193 or 112\"},\"Norway\":{\"police\": \"112\",\"ambulance\": \"113\",\"fire\": \"110\"},\"Poland\":{\"police\": \"112\",\"ambulance\": \"999 or 112\",\"fire\": \"998 or 112\"},\"Portugal\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Romania\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Russia\":{\"police\": \"102 or 112\",\"ambulance\": \"103 or 112\",\"fire\": \"101 or 112\"},\"San Marino\":{\"police\": \"113\",\"ambulance\": \"118\",\"fire\": \"115\"},\"Serbia\":{\"police\": \"192 or 112\",\"ambulance\": \"194\",\"fire\": \"193\"},\"Slovakia\":{\"police\": \"158\",\"ambulance\": \"155\",\"fire\": \"150\"},\"Slovenia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Spain\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Sweden\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Switzerland\":{\"police\": \"117\",\"ambulance\": \"144\",\"fire\": \"118\"},\"Turkey\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Ukraine\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"United Kingdom\":{\"police\": \"999 or 112\",\"ambulance\": \"999 or 112\",\"fire\": \"999 or 112\"},\"Vatican City\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"American Samoa\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Australia\":{\"police\": \"000\",\"ambulance\": \"000\",\"fire\": \"000\"},\"Cook Islands\":{\"police\": \"999\",\"ambulance\": \"998\",\"fire\": \"996\"},\"Fiji\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"French Polynesia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guam\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Kiribati\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Marshall Islands\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Micronesia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Nauru\":{\"police\": \"110\",\"ambulance\": \"111\",\"fire\": \"112\"},\"New Caledonia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"New Zealand\":{\"police\": \"111\",\"ambulance\": \"111\",\"fire\": \"111\"},\"Palau\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Papua New Guinea\":{\"police\": \"112\",\"ambulance\": \"111\",\"fire\": \"110\"},\"Samoa\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Solomon Islands\":{\"police\": \"911 or 999\",\"ambulance\": \"911o or 999\",\"fire\": \"911 or 999\"},\"Tonga\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Tuvalu\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Vanuata\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Belize\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Clipperton Island\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Costa Rica\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Guatemala\":{\"police\": \"110\",\"ambulance\": \"128\",\"fire\": \"122\"},\"El Salvador\":{\"police\": \"911\",\"ambulance\": \"132\",\"fire\": \"913\"},\"Honduras\":{\"police\": \"911\",\"ambulance\": \"195\",\"fire\": \"198\"},\"Nicaragua\":{\"police\": \"118\",\"ambulance\": \"128\",\"fire\": \"115\"},\"Panama\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Antigua and Barbuda\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Anguilla\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Aruba\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"The Bahamas\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"British Virgin Islands\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Cayman Islands\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Cuba\":{\"police\": \"106\",\"ambulance\": \"104\",\"fire\": \"105\"},\"Curacao\":{\"police\": \"911\",\"ambulance\": \"912\",\"fire\": \"911\"},\"Dominica\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Grenada\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Guadeloupe\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Martinique\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Montserrat\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Navassa Island\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Saint Kitts and Nevis\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Saint Lucia\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Saint Vincent and the Grenadines\":{\"police\": \"911 or 999 or 112\",\"ambulance\": \"911 or 999 or 112\",\"fire\": \"911 or 999 or 112\"},\"Bonaire\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Dominican Republic\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Haiti\":{\"police\": \"114\",\"ambulance\": \"116\",\"fire\": \"115\"},\"Puerto Rico\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Trinidad and Tobago\":{\"police\": \"911 or 999\",\"ambulance\": \"811\",\"fire\": \"990\"},\"Jamaica\":{\"police\": \"119\",\"ambulance\": \"110\",\"fire\": \"110\"},\"Bermuda\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Canada\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Mexico\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Saint Pierre and Miquelon\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"United States of America\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Argentina\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Bolivia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Brazil\":{\"police\": \"190\",\"ambulance\": \"192\",\"fire\": \"193\"},\"Chile\":{\"police\": \"133\",\"ambulance\": \"131\",\"fire\": \"132\"},\"Columbia\":{\"police\": \"123\",\"ambulance\": \"123\",\"fire\": \"123\"},\"Ecuador\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Falkland Islands\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"French Guiana\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guyana\":{\"police\": \"911\",\"ambulance\": \"913\",\"fire\": \"912\"},\"Paraguay\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Peru\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"South Georgia and the South Sandwich Islands\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Suriname\":{\"police\": \"115\",\"ambulance\": \"115\",\"fire\": \"115\"},\"Uruguay\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Venezuela\":{\"police\": \"911\",\"ambulance\": \"171\",\"fire\": \"171\"}}");
				JSONObject emergencyJson= (JSONObject) emergency;
				System.out.println("Desired ID: project_" + ids.get(j));
				System.out.println("Desired City: " + city.get(j).replace("\"", ""));
				System.out.println("Desired Country: " + country.get(j).replace("\"", ""));
				System.out.println("Desired Description: " + Description);
				System.out.println("Desired URL: " + url);
				System.out.println("Desired Emergency: " + emergencyJson.get(country.get(j).replace("\"", "").replace(" ", "_")));
				
				JSONObject numbers = (JSONObject) emergencyJson.get(country.get(j).replace("\"", "").replace(" ", "_"));
				ModelBuilder builderEmergency = new ModelBuilder();
				IRI emergencyInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "emergeny" + country.get(j).replace("\"", "").replace(" ", "_"));
				builderEmergency
				.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
				.subject(emergencyInstance)
			  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			  		.add(RDFS.LABEL, "emergeny" + country.get(j).replace("\"", "").replace(" ", "_"))
			  		.add(RDF.TYPE,"Xr:EmergNumber")
			  		.add("Xr:hasPoliceNumber", numbers.get("police").toString().replace("\"", ""))
			  		.add("Xr:hasFireNumber", numbers.get("fire").toString().replace("\"", ""))
			  		.add("Xr:hasAmbulanceNumber", numbers.get("fire").toString().replace("\"", ""))
			  		.add("Xr:hasCountry", country.get(j).replace("\"", "").replace(" ", "_"));
				GraphDB.add2(builderEmergency.build());
				
				
				ModelBuilder builderGeneral = new ModelBuilder();
				IRI generalInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "general" + city.get(j).replace("\"", "").replace(" ", "_"));
				builderGeneral
				.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
				.subject(generalInstance)
			  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			  		.add(RDFS.LABEL, "general" + city.get(j).replace("\"", "").replace(" ", "_"))
			  		.add(RDF.TYPE,"Xr:GeneralInfo")
			  		.add("Xr:hasDescription", Description)
			  		.add("Xr:hasURI", url)
			  		.add("Xr:hasLocation", "Xr:location" + city.get(j).replace("\"", "").replace(" ", "_"))
			  		.add("Xr:hasCountry", country.get(j).replace("\"", "").replace(" ", "_"));
				GraphDB.add2(builderGeneral.build());
				
				
				ModelBuilder builderLocation = new ModelBuilder();
				IRI locationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "location" + city.get(j).replace("\"", "").replace(" ", "_"));
				builderLocation
				.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
				.subject(locationInstance)
			  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
			  		.add(RDFS.LABEL, "location" + city.get(j).replace("\"", "").replace(" ", "_"))
			  		.add(RDF.TYPE,"Xr:Location")
			  		.add("Xr:hasGeolocation", city.get(j).replace("\"", "").replace(" ", "_"));
				GraphDB.add2(builderLocation.build());
				
		  }
	  }
	}
	catch(Exception e){
        System.err.println(e.getCause());}
	
	return "";
}

}