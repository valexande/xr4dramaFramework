
package alexTestRetrieve.xr4d_Retrieval;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

public class Server {
	public static final String REPOSITORY = "TestRep";
	public static final String SERVER = "http://xr4drama.iti.gr:7200";
}
