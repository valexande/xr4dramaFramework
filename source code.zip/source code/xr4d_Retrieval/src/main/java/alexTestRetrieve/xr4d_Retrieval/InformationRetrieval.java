
package alexTestRetrieve.xr4d_Retrieval;



import java.text.ParseException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;  
import java.time.Instant; 
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.*;
import java.util.Arrays;
import java.util.List;
import java.util.Base64;
import java.util.UUID;

import org.eclipse.rdf4j.model.IRI;
import org.eclipse.rdf4j.model.util.ModelBuilder;
import org.eclipse.rdf4j.model.util.Values;
import org.eclipse.rdf4j.model.vocabulary.OWL;
import org.eclipse.rdf4j.model.vocabulary.RDF;
import org.eclipse.rdf4j.model.vocabulary.RDFS;
import org.eclipse.rdf4j.query.BindingSet;
import org.eclipse.rdf4j.query.TupleQuery;
import org.eclipse.rdf4j.query.TupleQueryResult;
import org.eclipse.rdf4j.repository.Repository;
import org.eclipse.rdf4j.repository.RepositoryConnection;
import org.eclipse.rdf4j.repository.manager.RemoteRepositoryManager;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import com.mongodb.*;

import org.apache.commons.text.StringEscapeUtils;
import org.bson.BsonDocument;
import org.bson.BsonInt64;
import org.bson.Document;
import org.bson.conversions.Bson;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import java.net.URLEncoder;
import org.slf4j.LoggerFactory;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import org.slf4j.LoggerFactory;
import org.json.JSONException;
import org.json.JSONString;
import org.json.simple.JSONValue;

public class InformationRetrieval{
	
	public static String queriesInformation(String input) {
		
        Gson gson = new Gson();

        JsonElement json = gson.fromJson(input, JsonElement.class);
        JsonObject jobject = json.getAsJsonObject();

        RemoteRepositoryManager repositoryManager = new RemoteRepositoryManager(Server.SERVER);
        repositoryManager.initialize();

        Repository testRepository = repositoryManager.getRepository(Server.REPOSITORY);
        JSONObject response = new JSONObject();

        String query = 
        		"PREFIX xR: <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA>\r\n" +
                "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\r\n" +
        		"PREFIX Xr: <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA>\r\n"+
                "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n"+
        		"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\r\n"+
                "select ?country ?geo ?description ?legislation ?legislationDrone ?uri ?police ?firefighter ?ambulance where {\r\n"+
        		"Xr:project_" + jobject.get("project_id").toString().replace("\"", "") + " Xr:hasGeneralInfo ?general.\r\n"+
                "?general Xr:hasCountry ?country.\r\n"+
        		"?general Xr:hasDescription ?description.\r\n"+
        		"?general Xr:hasURI ?uri.\r\n"+
        		"?general Xr:hasLocation ?location.\r\n"+
        		"?location Xr:hasGeolocation ?geo.\r\n"+
        		"optional{Xr:project_" + jobject.get("project_id").toString().replace("\"", "") + " Xr:hasLegalDocument ?legal .\r\n"+
        		"?legal Xr:legalInformationVideo ?legislation}\r\n"+
        		"optional{Xr:project_" + jobject.get("project_id").toString().replace("\"", "") + " Xr:hasLegalDocument ?legal .\r\n"+
        		"?legal Xr:legalInformationDrone ?legislationDrone}\r\n"+
        		"Xr:project_" + jobject.get("project_id").toString().replace("\"", "") + " Xr:hasEmergencyNumber ?emergency .\r\n"+
        		"?emergency Xr:hasPoliceNumber ?police .\r\n"+
                "?emergency Xr:hasFireNumber ?firefighter .\r\n"+
        		"?emergency Xr:hasAmbulanceNumber ?ambulance }";

        System.out.println(query);
        // Open a connection to the database
        RepositoryConnection testRepoConnection = testRepository.getConnection();

        TupleQuery tupleQuery = testRepoConnection.prepareTupleQuery(query);

        TupleQueryResult qresult = tupleQuery.evaluate();
        JSONObject jsonResponse = new JSONObject();
        
        try {
          while (qresult.hasNext()) {
                BindingSet st = qresult.next();
                if (st.hasBinding("country") && st.hasBinding("description") && st.hasBinding("uri")) {
                	jsonResponse.put("country", st.getValue("country").toString().replace("\"", ""));
                	jsonResponse.put("description", st.getValue("description").toString());
                	jsonResponse.put("uri", st.getValue("uri").toString().replace("^^<http://www.w3.org/2001/XMLSchema#anyURI>", "").replace("\"", ""));
                }
                if (st.hasBinding("police") && st.hasBinding("firefighter") && st.hasBinding("ambulance")) {
                	JSONObject jsonNumber = new JSONObject();
                	jsonNumber.put("police", st.getValue("police").toString().replace("\"", "")); 
                	jsonNumber.put("firefighter", st.getValue("firefighter").toString().replace("\"", "")); 
                	jsonNumber.put("ambulance", st.getValue("ambulance").toString().replace("\"", ""));
                	jsonResponse.put("emergency number", jsonNumber);
                }
                if(st.hasBinding("geo")) {
                	jsonResponse.put("location", st.getValue("geo").toString().replace("\"", ""));
                }
                if(st.hasBinding("legislation")) {
                	jsonResponse.put("legislationVideo", st.getValue("legislation").toString().replace("\"", ""));
                }
                if(st.hasBinding("legislationDrone")) {
                	jsonResponse.put("legislationDrone", st.getValue("legislationDrone").toString().replace("\"", ""));
                }
          }
        }
        catch(Exception e){
	        System.err.println(e.getCause());
	    }
        
        
        
        testRepoConnection.close();
        
        
        if(jsonResponse.length()  == 0) {
        	
	       	 String responseEmergency = mapEmergencyGeneral(jobject.get("project_id").toString().replace("\"", ""));
	        
	    	 System.out.println("All set for porject id: " + jobject.get("project_id").toString().replace("\"", ""));
		        Gson gsonEw = new Gson();

		        JsonElement jsonNew = gsonEw.fromJson(input, JsonElement.class);
		        JsonObject jobjectNew = jsonNew.getAsJsonObject();

		        RemoteRepositoryManager repositoryManagerNew = new RemoteRepositoryManager(Server.SERVER);
		        repositoryManager.initialize();

		        Repository testRepositoryNew = repositoryManagerNew.getRepository(Server.REPOSITORY);
		        JSONObject responseNew = new JSONObject();

		        String queryNew = 
		        		"PREFIX xR: <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA>\r\n" +
		                        "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\r\n" +
		                		"PREFIX Xr: <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA>\r\n"+
		                        "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n"+
		                		"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\r\n"+
		                        "select ?country ?geo ?description ?legislation ?legislationDrone ?uri ?police ?firefighter ?ambulance where {\r\n"+
		                		"Xr:project_" + responseEmergency + " Xr:hasGeneralInfo ?general.\r\n"+
		                        "?general Xr:hasCountry ?country.\r\n"+
		                		"?general Xr:hasDescription ?description.\r\n"+
		                		"?general Xr:hasURI ?uri.\r\n"+
		                		"?general Xr:hasLocation ?location.\r\n"+
		                		"?location Xr:hasGeolocation ?geo.\r\n"+
		                		"optional{Xr:project_" + responseEmergency + " Xr:hasLegalDocument ?legal .\r\n"+
		                		"?legal Xr:legalInformationVideo ?legislation}\r\n"+
		                		"optional{Xr:project_" + responseEmergency + " Xr:hasLegalDocument ?legal .\r\n"+
		                		"?legal Xr:legalInformationDrone ?legislationDrone}\r\n"+
		                		"Xr:project_" + responseEmergency + " Xr:hasEmergencyNumber ?emergency .\r\n"+
		                		"?emergency Xr:hasPoliceNumber ?police .\r\n"+
		                        "?emergency Xr:hasFireNumber ?firefighter .\r\n"+
		                		"?emergency Xr:hasAmbulanceNumber ?ambulance }";

	            System.out.println(query);
	            // Open a connection to the database
	            RepositoryConnection testRepoConnectionNew = testRepositoryNew.getConnection();

	            TupleQuery tupleQueryNew = testRepoConnectionNew.prepareTupleQuery(query);

	            TupleQueryResult qresultNew = tupleQueryNew.evaluate();
	            JSONObject jsonResponseNew = new JSONObject();
	            
	            try {
	              while (qresultNew.hasNext()) {
	                    BindingSet st = qresultNew.next();
	                    if (st.hasBinding("country") && st.hasBinding("description") && st.hasBinding("uri")) {
	                    	jsonResponseNew.put("country", st.getValue("country").toString().replace("\"", ""));
	                    	jsonResponseNew.put("description", st.getValue("description").toString().replace("\"", ""));
	                    	jsonResponseNew.put("uri", st.getValue("uri").toString().replace("^^<http://www.w3.org/2001/XMLSchema#anyURI>", "").replace("\"", ""));
	                    }
	                    if (st.hasBinding("police") && st.hasBinding("firefighter") && st.hasBinding("ambulance")) {
	                    	JSONObject jsonNumber = new JSONObject();
	                    	jsonNumber.put("police", st.getValue("police").toString().replace("\"", "")); 
	                    	jsonNumber.put("firefighter", st.getValue("firefighter").toString().replace("\"", "")); 
	                    	jsonNumber.put("ambulance", st.getValue("ambulance").toString().replace("\"", ""));
	                    	jsonResponse.put("emergency number", jsonNumber);
	                    }
	                    if(st.hasBinding("geo")) {
	                    	jsonResponseNew.put("location", st.getValue("geo").toString().replace("\"", ""));
	                    }
	                    if(st.hasBinding("legislation")) {
	                    	jsonResponseNew.put("legislation", st.getValue("legislation").toString().replace("\"", ""));
	                    }
	              }
	            }
	            catch(Exception e){
			        System.err.println(e.getCause());
			    }
	            return jsonResponseNew.toString();
        
        }
	
        
        return jsonResponse.toString();
	}

	public static String sendGetRequestStr(String url)
	  {
	      try{
	          URL obj = new URL(url);
	          HttpURLConnection con = (HttpURLConnection) obj.openConnection();

	          //add request header
	          con.setRequestMethod("GET");
	          con.setRequestProperty("Accept", "application/json");
	          con.setRequestProperty("Authorization","Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxZjEzYjM2NGE0MjQ3MTYwMGY3OTUyMGZlM2M2NzVhOTJhNmQ3ZjFjIiwianRpIjoiZTI4YjNmOWE4N2QzM2IxZDY2MDY2YmViNmY4ZmQ1NTk4Yzc5YmQ0MDM1MzcwNWI1MmYzMTc1ZjMxNzMzMzNkZjZlYzY1Mjg4Yjg4Y2U1ZGYiLCJpYXQiOjE2NjU1NjcwODAsIm5iZiI6MTY2NTU2NzA4MCwiZXhwIjoxNjY1NTcwNjgwLCJzdWIiOiJbXCJ1c2VyXCIsMjZdIiwic2NvcGVzIjpbXX0.uZ6mvhkIQkkG0jtFikuoZKqACPNuRLXwB1qEjbhoT6nV5mGWJpOlhr9OWufvO2FiIZ6NM8HVIXlZZj9olxwf0Seo2OK4GeziHkRIScEx7Tt3hS087u9FaIoAo3hm8pe0p0mfI8FYO7ddltUl5URhxwpDv64pizByveM4ajiQdbq31BaAR1bmugW4NguBBullpy4vgwwIg9KZMIhO9KvKq8Cj6sM1kskYp0FHHb53DrJ1hkKSXWuwhWRhJLCfDbNTD7gxu51FdceC31H1abAbFZghh9pMcsg4PH5FbZHcNZNlSfliASEY9-ih9DGc-dHPUoCdhO4JECDCi4xardAKTA");

	          int responseCode = con.getResponseCode();

	          System.out.println("Sending 'GET' request to URL : " + url);
	          System.out.println("Response Code : " + responseCode);

	          if(responseCode!=200 && responseCode!=201)
	              return "Error code returned: "+responseCode;

	          BufferedReader in = new BufferedReader(
	                  new InputStreamReader(con.getInputStream()));
	          String inputLine;
	          StringBuffer response = new StringBuffer();

	          while ((inputLine = in.readLine()) != null) {
	              response.append(inputLine + "\n");
	          }
	          in.close();
	          return response.toString();
	      }
	      catch(IOException io){
	          System.out.println(io.getMessage());
	          return "IO Exception: " + io.getMessage();
	      }
	  }

	public static String sendGetRequestStrGIS(String url)
	  {
	      try{
	          URL obj = new URL(url);
	          HttpURLConnection con = (HttpURLConnection) obj.openConnection();

	          //add request header
	          con.setRequestMethod("GET");
	          con.setRequestProperty("User-Agent", "Mozilla/5.0");
	          con.setRequestProperty("api_key","8t8YKQegHHl4gMCPd5TF");

	          int responseCode = con.getResponseCode();

	          System.out.println("Sending 'GET' request to URL : " + url);
	          System.out.println("Response Code : " + responseCode);

	          if(responseCode!=200 && responseCode!=201)
	              return "Error code returned: "+responseCode;

	          BufferedReader in = new BufferedReader(
	                  new InputStreamReader(con.getInputStream()));
	          String inputLine;
	          StringBuffer response = new StringBuffer();

	          while ((inputLine = in.readLine()) != null) {
	              response.append(inputLine + "\n");
	          }
	          in.close();
	          return response.toString();
	      }
	      catch(IOException io){
	          System.out.println(io.getMessage());
	          return "IO Exception: " + io.getMessage();
	      }
	  }
	  	
	public static String sendPostRequestRawStrGIS(String url, String body, String format,
	          String... creds)
			{
			try{
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			
			//add request header
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", "Mozilla/5.0");
			con.setRequestProperty("content-type",format);
			con.setRequestProperty("api_key","8t8YKQegHHl4gMCPd5TF");
			
			// credentials
			if(creds.length == 2){
			String encoded = Base64.getEncoder()
			.encodeToString((creds[0]+":"+creds[1]).getBytes(StandardCharsets.UTF_8));  //Java 8
			con.setRequestProperty("Authorization", "Basic "+encoded);
			}
			
			// Send post request
			System.out.println("Sending 'POST' request to URL : " + url);
			con.setDoOutput(true);
			
			
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(), "UTF-8"));
			bw.write(body);
			bw.flush();
			bw.close();
			
			
			int responseCode = con.getResponseCode();
			String responseText = con.getResponseMessage();
			
			
			System.out.println("Response Code : " + responseCode);
			
			//if(responseCode!=200 && responseCode!=409)
			if(responseCode!=200 && responseCode!=201 )
			return "Error code returned: "+responseCode;
			
			BufferedReader in = new BufferedReader(
			new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
			String inputLine;
			StringBuffer response = new StringBuffer();
			
			while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
			}
			in.close();
			System.out.println(response.toString());
			return response.toString();
			}
			catch(IOException io){
			System.out.println(io.getMessage());
			return "IO Exception: " + io.getMessage();
			}
			}

	public static String sendDeleteRequestStrGIS(String url)
	  {
	      try{
	          URL obj = new URL(url);
	          HttpURLConnection con = (HttpURLConnection) obj.openConnection();

	          //add request header
	          con.setRequestMethod("DELETE");
	          con.setRequestProperty("User-Agent", "Mozilla/5.0");
	          con.setRequestProperty("api_key","8t8YKQegHHl4gMCPd5TF");

	          int responseCode = con.getResponseCode();

	          System.out.println("Sending 'DELETE' request to URL : " + url);
	          System.out.println("Response Code : " + responseCode);

	          if(responseCode!=200 && responseCode!=201)
	              return "Error code returned: "+responseCode;

	          BufferedReader in = new BufferedReader(
	                  new InputStreamReader(con.getInputStream()));
	          String inputLine;
	          StringBuffer response = new StringBuffer();

	          while ((inputLine = in.readLine()) != null) {
	              response.append(inputLine + "\n");
	          }
	          in.close();
	          return response.toString();
	      }
	      catch(IOException io){
	          System.out.println(io.getMessage());
	          return "IO Exception: " + io.getMessage();
	      }
	  }

	public static String dangerZone(String jsonDSS) {
	      Gson gson = new Gson();
	      JsonElement json = gson.fromJson(jsonDSS, JsonElement.class);
	      JsonObject dss = json.getAsJsonObject();
	     
	      ///capture related danger zones///
	      double latitude = dss.get("latitude").getAsDouble();
	      double longitude = dss.get("longitude").getAsDouble();
	      JSONObject objectDSSDanger = new JSONObject();
	      ArrayList<String> dangerZoneID = new ArrayList<String>();
	      ArrayList<String> dangerZoneOldSeverity = new ArrayList<String>();
	      double nwLatDanger = 0;
	      double seLatDanger = 0;
	      double nwLonDanger = 0;
	      double seLonDanger = 0;
	      try{
	     	   String responseDanger = "";
	        	   responseDanger = sendGetRequestStrGIS("https://geoservice.xr4drama.up2metric.com:8001/projects/" + dss.get("project_id").toString().replace("\"", "") + "/danger-zones");
	        	   JsonElement jsonDanger = gson.fromJson(responseDanger, JsonElement.class);
	         	   for (int i=0; i < jsonDanger.getAsJsonArray().size();i++) {
	         		   JsonObject danger = jsonDanger.getAsJsonArray().get(i).getAsJsonObject();
	  	   		   nwLatDanger = danger.get("location_nw").getAsJsonObject().get("latitude").getAsDouble();
	  	   		   seLatDanger = danger.get("location_se").getAsJsonObject().get("latitude").getAsDouble();
	  	   		   nwLonDanger = danger.get("location_nw").getAsJsonObject().get("longitude").getAsDouble();
	  	   		   seLonDanger = danger.get("location_se").getAsJsonObject().get("longitude").getAsDouble();
	  	   		   System.out.println(nwLatDanger);
	  	   		   System.out.println(seLatDanger);
	  	   		   System.out.println(nwLonDanger);
	  	   		   System.out.println(seLonDanger);
		   		   if( seLatDanger <= latitude && latitude <= nwLatDanger && nwLonDanger <= longitude && longitude <= seLonDanger ) {
		   			   dangerZoneID.add(danger.get("id").toString());
		   			   dangerZoneOldSeverity.add(danger.get("description").toString().split(": ")[1].toString().replace("\"", ""));
		   			}
	         	   }
	 	    } catch(Exception e){
	 	        System.err.println(e.getCause());
	 	    }
		  ///capture related ganger zones//// 
	      
	      //dangerZoneID.clear();
	      System.out.println(dangerZoneID);
	      System.out.println(dangerZoneOldSeverity);
	      if (dangerZoneID.size() > 0 ) {
	    	  ///updated danger zones
	    	for (int i =0; i < dangerZoneOldSeverity.size(); i++) {
	    		if (dangerZoneOldSeverity.get(i).toString().equals("low")) {
	    			//low old severity thus delete and create a new danger zone
	    		sendDeleteRequestStrGIS("https://geoservice.xr4drama.up2metric.com:8001/projects/" + dss.get("project_id").toString().replace("\"", "") + "/danger-zones/" + dangerZoneID.get(i));
	    	  
	    	  JSONObject newDangerZone = new JSONObject();
	    	  JSONObject location_nw = new JSONObject();
	    	  JSONObject location_se = new JSONObject();
	    	  double latnw = latitude + 0.0001;
	    	  double lngnw = longitude - 0.0001;
	    	  double latse = latitude - 0.0001;
	    	  double lngse = longitude + 0.0001;
	    	  location_nw.put("latitude", latnw);
	    	  location_nw.put("longitude", lngnw);
	    	  location_se.put("latitude", latse);
	    	  location_se.put("longitude", lngse);
	    	  

	    	  newDangerZone.put("location_nw", location_nw);
	    	  newDangerZone.put("location_se", location_se);
	    	  newDangerZone.put("level", 2);
	    	  newDangerZone.put("headline", "Severity of the Danger Zone");
	    	  newDangerZone.put("description", "The severity of the area is: " + dss.get("severityDSS").toString().replace("\"", ""));

	    	  System.out.println(newDangerZone);
	    	  String id = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + dss.get("project_id").toString().replace("\"", "") + "/danger-zones";
		      sendPostRequestRawStrGIS(id, newDangerZone.toString(), "application/json");
	    	  }
	    		else {
	    			//merge danger zones due to high old severity score
	    			sendDeleteRequestStrGIS("https://geoservice.xr4drama.up2metric.com:8001/projects/" + dss.get("project_id").toString().replace("\"", "") + "/danger-zones/" + dangerZoneID.get(i));
	    	    	  JSONObject newDangerZone = new JSONObject();
	    	    	  JSONObject location_nw = new JSONObject();
	    	    	  JSONObject location_se = new JSONObject();
	    	    	  double latnw = latitude + 0.0001;
	    	    	  double lngnw = longitude - 0.0001;
	    	    	  double latse = latitude - 0.0001;
	    	    	  double lngse = longitude + 0.0001;
	    	    	  if (latnw < nwLatDanger){
	    	    		  latnw = nwLatDanger;
	    	    	  }
	    	    	  if (latse < seLatDanger){
	    	    		  latse = nwLatDanger;
	    	    	  }
	    	    	  if (lngnw < nwLonDanger){
	    	    		  lngnw = nwLonDanger;
	    	    	  }
	    	    	  if (lngse < seLonDanger){
	    	    		  lngse = seLonDanger;
	    	    	  }
	    	    	  location_nw.put("latitude", latnw);
	    	    	  location_nw.put("longitude", lngnw);
	    	    	  location_se.put("latitude", latse);
	    	    	  location_se.put("longitude", lngse);
	    	    	  

	    	    	  newDangerZone.put("location_nw", location_nw);
	    	    	  newDangerZone.put("location_se", location_se);
	    	    	  newDangerZone.put("level", 2);
	    	    	  newDangerZone.put("headline", "Severity of the Danger Zone");
	    	    	  newDangerZone.put("description", "The severity of the area is: " + dss.get("severityDSS").toString().replace("\"", ""));

	    	    	  System.out.println(newDangerZone);
	    	    	  String id = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + dss.get("project_id").toString().replace("\"", "") + "/danger-zones";
	    		      sendPostRequestRawStrGIS(id, newDangerZone.toString(), "application/json");
	    		}
	    	}
	      }
	      else {
	    	  //create new danger zones
	    	  JSONObject newDangerZone = new JSONObject();
	    	  JSONObject location_nw = new JSONObject();
	    	  JSONObject location_se = new JSONObject();
	    	  double latnw = latitude + 0.0001;
	    	  double lngnw = longitude - 0.0001;
	    	  double latse = latitude - 0.0001;
	    	  double lngse = longitude + 0.0001;
	    	  location_nw.put("latitude", latnw);
	    	  location_nw.put("longitude", lngnw);
	    	  location_se.put("latitude", latse);
	    	  location_se.put("longitude", lngse);
	    	  

	    	  newDangerZone.put("location_nw", location_nw);
	    	  newDangerZone.put("location_se", location_se);
	    	  newDangerZone.put("level", 2);
	    	  newDangerZone.put("headline", "Severity of the Danger Zone");
	    	  newDangerZone.put("description", "The severity of the area is: " + dss.get("severityDSS").toString().replace("\"", ""));

	    	  System.out.println(newDangerZone);
	    	  String id = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + dss.get("project_id").toString().replace("\"", "") + "/danger-zones";
		      sendPostRequestRawStrGIS(id, newDangerZone.toString(), "application/json");
	      }
	      
		  return "The danger zones were updated";
	  }

	public static String mapEmergencyGeneral(String projectID) {
		System.out.println("This is the project id: " + projectID);
		
		try {
			String response = sendGetRequestStrGIS("https://geoservice.xr4drama.up2metric.com:8001/projects/");
		   String[] parts = response.split("\"id\":");
		   String[] cities = response.split("\"city\":");
		   String[] countries = response.split("\"country\":");
		   List<String> ids = new ArrayList<String>();
		   List<String> city = new ArrayList<String>();
		   List<String> country = new ArrayList<String>();
		   for(int j = 1; j< parts.length; j++){
			   ids.add(parts[j].split(",\"status\"")[0].toString());
			   city.add(cities[j].split(",\"country\"")[0].toString());
			   country.add(countries[j].split(",\"description\"")[0].toString());
			   }
		   
		  List<String> desiredProject = new ArrayList<String>();
		  for (int j = 1; j<ids.size(); j++) {
			  if (ids.get(j).equals(projectID)) {
				  
					ModelBuilder builder = new ModelBuilder();
					IRI ProjectInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "project_" + ids.get(j));
					builder
					.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
					.subject(ProjectInstance)
				  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
				  		.add(RDFS.LABEL, "project_"+ ids.get(j))
				  		.add(RDF.TYPE,"Xr:Project")
				  		.add("Xr:hasGeneralInfo", "Xr:general" + city.get(j).replace("\"", "").replace(" ", "_"))
				  		.add("Xr:hasEmergencyNumber", "Xr:emergeny" + country.get(j).replace("\"", "").replace(" ", "_"));
					GraphDB.add2(builder.build());
					
					
					if (country.get(j).replace("\"", "").replace(" ", "_").equals("Greece")) {
						ModelBuilder builderLegislation = new ModelBuilder();
						IRI legislationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "project_" + ids.get(j));
						builderLegislation
						.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
						.subject(legislationInstance)
					  		.add("Xr:hasLegalDocument", "Xr:legal" + country.get(j).replace("\"", "").replace(" ", "_"));
						GraphDB.add2(builderLegislation.build());
					}
					if (city.get(j).replace("\"", "").replace(" ", "_").equals("Berlin")) {
						
						
						ModelBuilder builderLegislation = new ModelBuilder();
						IRI legislationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "project_" + ids.get(j));
						builderLegislation
						.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
						.subject(legislationInstance)
					  		.add("Xr:hasLegalDocument", "Xr:legal" + city.get(j).replace("\"", "").replace(" ", "_"));
						GraphDB.add2(builderLegislation.build());
						
					}
					if (city.get(j).replace("\"", "").replace(" ", "_").equals("Bonn")) {
						ModelBuilder builderLegislation = new ModelBuilder();
						IRI legislationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "project_" + ids.get(j));
						builderLegislation
						.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
						.subject(legislationInstance)
					  		.add("Xr:hasLegalDocument", "Xr:legal" + city.get(j).replace("\"", "").replace(" ", "_"));
						GraphDB.add2(builderLegislation.build());
					}
					
					String responseWikipedia = sendGetRequestStr("https://www.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro=&explaintext=&titles=" + city.get(j).replace("\"", "").replace(" ", "_"));
					String Description = "";
					String url = "";
					if (responseWikipedia.contains("-1")) {
						 Description = "Wikipedia could not return description for " + city.get(j).replace("\"", "").replace(" ", "_") + " please try only the name of the city";
						 url = "Wikipedia could not return url for " + city.get(j).replace("\"", "").replace(" ", "_") + " please try only the name of the city";
					}
					else{
						Gson gson = new Gson();
						//String normalized_string = Normalizer.normalize(responseWikipedia, Normalizer.Form.NFD);
						String resultString = responseWikipedia.split("\"extract\":")[1].toString().replace("}}}}", "");;
						Description = StringEscapeUtils.unescapeJava(resultString);

						url = "https://en.wikipedia.org/wiki/" + city.get(j).replace("\"", "");
					}
					Object emergency=JSONValue.parse("{\"Algeria\" :{\"police\": \"1548\",\"ambulance\": \"14\",\"fire\": \"14\"},\"Angola\":{\"police\": \"113\",\"ambulance\": \"112/116\",\"fire\": \"115\"},	\"Ascension Island\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Benin\":{\"police\": \"117\",\"ambulance\": \"112\",\"fire\": \"118\"},\"Botswana\":{\"police\": \"999\",\"ambulance\": \"997\",\"fire\": \"998\"},\"Burkina Faso\":{\"police\": \"17\",\"ambulance\": \"112\",\"fire\": \"18\"},\"Cameroon\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"111\"},\"Cape Verde\":{\"police\": \"132\",\"ambulance\": \"130\",\"fire\": \"131\"},\"Central African Republic\":{\"police\": \"117\",\"ambulance\": \"1220\",\"fire\": \"118\"},\"Chad\":{\"police\": \"17\",\"ambulance\": \"2551-4242\",\"fire\": \"18\"},\"Comoros\":{\"police\": \"17\",\"ambulance\": \"772-03-73\",\"fire\": \"18\"},\"Republic of Congo\":{\"police\": \"117\",\"ambulance\": \"None\",\"fire\": \"118\"},\"Democratic Republic of Congo\":{\"police\": \"112\",\"ambulance\": \"\",\"fire\": \"118\"},\"Djibouti\":{\"police\": \"17\",\"ambulance\": \"19\",\"fire\": \"18\"},\"Egypt\":{\"police\": \"122\",\"ambulance\": \"123\",\"fire\": \"180\"},\"Equatorial Guinea\":{\"police\": \"114\",\"ambulance\": \"115\",\"fire\": \"112\"},\"Eritrea\":{\"police\": \"113\",\"ambulance\": \"114\",\"fire\": \"116\"},\"Eswatini\":{\"police\": \"999\",\"ambulance\": \"977\",\"fire\": \"933\"},\"Ethiopia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Gabon\":{\"police\": \"1730\",\"ambulance\": \"1300\",\"fire\": \"18\"},\"Gambia\":{\"police\": \"117\",\"ambulance\": \"116\",\"fire\": \"118\"},\"Ghana\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guinea\":{\"police\": \"117\",\"ambulance\": \"18\",\"fire\": \"442-020\"},\"Guinea-Bissau\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Ivory Coast\":{\"police\": \"110 or 111 or 170\",\"ambulance\": \"185\",\"fire\": \"180\"},\"Liberia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Kenya\":{\"police\": \"112 or 999 or 911\",\"ambulance\": \"112 or 999 or 911\",\"fire\": \"112 or 999 or 911\"},\"Libya\":{\"police\": \"1515\",\"ambulance\": \"1515\",\"fire\": \"1515\"},\"Lesotho\":{\"police\": \"123\",\"ambulance\": \"121\",\"fire\": \"122\"},\"Madagascar\":{\"police\": \"117\",\"ambulance\": \"124\",\"fire\": \"118\"},\"Malawi\":{\"police\": \"997\",\"ambulance\": \"998\",\"fire\": \"999\"},\"Mali\":{\"police\": \"17\",\"ambulance\": \"15\",\"fire\": \"18\"},\"Mauritius\":{\"police\": \"112\",\"ambulance\": \"114\",\"fire\": \"115\"},\"Mauritania\":{\"police\": \"117\",\"ambulance\": \"101\",\"fire\": \"118\"},\"Mayotte\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Morocco\":{\"police\": \"19\",\"ambulance\": \"15\",\"fire\": \"15\"},\"Mozambique\":{\"police\": \"119\",\"ambulance\": \"117\",\"fire\": \"198\"},\"Nambia\":{\"police\": \"10111\",\"ambulance\": \"depeding on town/city\",\"fire\": \"depending on town/city\"},\"Nigeria\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Niger\":{\"police\": \"17\",\"ambulance\": \"15\",\"fire\": \"18\"},\"Reunion\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Rwanda\":{\"police\": \"112\",\"ambulance\": \"912\",\"fire\": \"112\"},\"Saint Helena\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Sao Tome and Principe\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Senegal\":{\"police\": \"17\",\"ambulance\": \"18\",\"fire\": \"1515\"},\"Seychelles\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Sierra Leone\":{\"police\": \"019\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Somalia\":{\"police\": \"888\",\"ambulance\": \"999\",\"fire\": \"555\"},\"South Africa\":{\"police\": \"10111\",\"ambulance\": \"10117\",\"fire\": \"10117\"},\"Sudan\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"South Sudan\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Tanzania\":{\"police\": \"112\",\"ambulance\": \"114\",\"fire\": \"115\"},\"Togo\":{\"police\": \"117\",\"ambulance\": \"8200\",\"fire\": \"118\"},\"Tristan da Cuhna\":{\"police\": \"999\",\"ambulance\": \"911\",\"fire\": \"999\"},\"Tunisia\":{\"police\": \"197\",\"ambulance\": \"190\",\"fire\": \"198\"},\"Uganda\":{\"police\": \"112\",\"ambulance\": \"911\",\"fire\": \"112\"},\"Western Sahara\":{\"police\": \"150\",\"ambulance\": \"150\",\"fire\": \"150\"},\"Zambia\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Zimbabwe\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Antarctica\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Afghanistan\":{\"police\": \"119\",\"ambulance\": \"112\",\"fire\": \"119\"},\"Bahrain\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Bangladesh\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Bhutan\":{\"police\": \"113\",\"ambulance\": \"112\",\"fire\": \"110\"},\"British Indian Ocean Territory\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Brunei\":{\"police\": \"993\",\"ambulance\": \"991\",\"fire\": \"995\"},\"Myanmar\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Cambodia\":{\"police\": \"117\",\"ambulance\": \"119\",\"fire\": \"118\"},\"Peoples Republic of China\":{\"police\": \"110\",\"ambulance\": \"120\",\"fire\": \"119\"},\"Christmas Island\":{\"police\": \"000\",\"ambulance\": \"000\",\"fire\": \"000\"},\"Cocos Islands\":{\"police\": \"000\",\"ambulance\": \"000\",\"fire\": \"000\"},\"East Timor\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Hong Kong\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"India\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Indonesia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Iran\":{\"police\": \"110\",\"ambulance\": \"115\",\"fire\": \"125\"},\"Iraq\":{\"police\": \"112 or 911\",\"ambulance\": \"112 or 911\",\"fire\": \"112 or 911\"},\"Israel\":{\"police\": \"100\",\"ambulance\": \"101\",\"fire\": \"102\"},\"Japan\":{\"police\": \"110\",\"ambulance\": \"119\",\"fire\": \"119\"},\"Jordan\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Kazakhstan\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Kyrgyzstan\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"Democratic People's Republic of Korea\":{\"police\": \"local numbers only\",\"ambulance\": \"local numbers only\",\"fire\": \"8119\"},\"Republic of Korea\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"119\"},\"Kuwait\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Laos\":{\"police\": \"191\",\"ambulance\": \"195\",\"fire\": \"190\"},\"Lebanon\":{\"police\": \"999 or 112\",\"ambulance\": \"140\",\"fire\": \"175\"},\"Macau\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Maldives\":{\"police\": \"119\",\"ambulance\": \"102\",\"fire\": \"118\"},\"Malaysia\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"994\"},\"Mongolia\":{\"police\": \"105\",\"ambulance\": \"105\",\"fire\": \"105\"},\"Nepal\":{\"police\": \"100\",\"ambulance\": \"102\",\"fire\": \"101\"},\"Oman\":{\"police\": \"9999\",\"ambulance\": \"9999\",\"fire\": \"9999\"},\"Pakistan\":{\"police\": \"115\",\"ambulance\": \"115 and 1122\",\"fire\": \"16\"},\"Philippines\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Qatar\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Saudi Arabia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Singapore\":{\"police\": \"999\",\"ambulance\": \"995\",\"fire\": \"995\"},\"Sri Lanka\":{\"police\": \"119\",\"ambulance\": \"110\",\"fire\": \"110\"},\"Syria\":{\"police\": \"112\",\"ambulance\": \"110\",\"fire\": \"113\"},\"Republic of Chine (Taiwan)\":{\"police\": \"110\",\"ambulance\": \"119\",\"fire\": \"119\"},\"Tajikistan\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Thailand\":{\"police\": \"191 or 911\",\"ambulance\": \"1669\",\"fire\": \"199\"},\"Turkmenistan\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"United Arab Emirates\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Uzbekistan\":{\"police\": \"102\",\"ambulance\": \"101\",\"fire\": \"103\"},\"Vietnam\":{\"police\": \"113\",\"ambulance\": \"115\",\"fire\": \"114\"},\"Yemen\":{\"police\": \"194\",\"ambulance\": \"191\",\"fire\": \"191\"},\"Akrotiri and Dhekelia\":{\"police\": \"112\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Aland Islands\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Albania\":{\"police\": \"129\",\"ambulance\": \"127\",\"fire\": \"128\"},\"Andorra\":{\"police\": \"110\",\"ambulance\": \"116\",\"fire\": \"118\"},\"Armenia\":{\"police\": \"112 or 911\",\"ambulance\": \"112 or 911\",\"fire\": \"112 or 911\"},\"Austria\":{\"police\": \"112 or 133\",\"ambulance\": \"144\",\"fire\": \"122\"},\"Azerbaijan\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"Belarus\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"Belgium\":{\"police\": \"101 or 112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Bosnia and Herzegovina\":{\"police\": \"122\",\"ambulance\": \"124\",\"fire\": \"123\"},\"Bulgaria\":{\"police\": \"112 or 166\",\"ambulance\": \"112 or 150\",\"fire\": \"112 or 160\"},\"Croatia\":{\"police\": \"112 or 192\",\"ambulance\": \"999 or 194\",\"fire\": \"999 or 193\"},\"Cyprus\":{\"police\": \"112 or 199\",\"ambulance\": \"999 or 199\",\"fire\": \"999 or 199\"},\"Czech Republic\":{\"police\": \"112 or 158\",\"ambulance\": \"112 or 155\",\"fire\": \"112 or 150\"},\"Denmark\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Estonia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Faroe Islands\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Finland\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"France\":{\"police\": \"112 or 17\",\"ambulance\": \"112 or 15\",\"fire\": \"112 or 18\"},\"Georgia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Germany\":{\"police\": \"110\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Gibraltar\":{\"police\": \"199 or 112 or 999\",\"ambulance\": \"190 or 112 or 999\",\"fire\": \"190 or 112 or 999\"},\"Greece\":{\"police\": \"100\",\"ambulance\": \"166\",\"fire\": \"199\"},\"Greenland\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guemsey\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Hungary\":{\"police\": \"112 or 107\",\"ambulance\": \"112 or 104\",\"fire\": \"112 or 105\"},\"Iceland\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Ireland\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Isle of Man\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Italy\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Jersey\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"Kosovo\":{\"police\": \"192\",\"ambulance\": \"194\",\"fire\": \"193\"},\"Latvia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Lithuania\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Liechtenstein\":{\"police\": \"117\",\"ambulance\": \"144\",\"fire\": \"118\"},\"Luxembourg\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Malta\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Moldova\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Monaco\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Monaco\":{\"police\": \"17\",\"ambulance\": \"15\",\"fire\": \"18\"},\"Montenegro\":{\"police\": \"122\",\"ambulance\": \"124\",\"fire\": \"123\"},\"Netherlands\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"North Macedonia\":{\"police\": \"192 or 112\",\"ambulance\": \"194 or 112\",\"fire\": \"193 or 112\"},\"Norway\":{\"police\": \"112\",\"ambulance\": \"113\",\"fire\": \"110\"},\"Poland\":{\"police\": \"112\",\"ambulance\": \"999 or 112\",\"fire\": \"998 or 112\"},\"Portugal\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Romania\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Russia\":{\"police\": \"102 or 112\",\"ambulance\": \"103 or 112\",\"fire\": \"101 or 112\"},\"San Marino\":{\"police\": \"113\",\"ambulance\": \"118\",\"fire\": \"115\"},\"Serbia\":{\"police\": \"192 or 112\",\"ambulance\": \"194\",\"fire\": \"193\"},\"Slovakia\":{\"police\": \"158\",\"ambulance\": \"155\",\"fire\": \"150\"},\"Slovenia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Spain\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Sweden\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Switzerland\":{\"police\": \"117\",\"ambulance\": \"144\",\"fire\": \"118\"},\"Turkey\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Ukraine\":{\"police\": \"102\",\"ambulance\": \"103\",\"fire\": \"101\"},\"United Kingdom\":{\"police\": \"999 or 112\",\"ambulance\": \"999 or 112\",\"fire\": \"999 or 112\"},\"Vatican City\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"American Samoa\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Australia\":{\"police\": \"000\",\"ambulance\": \"000\",\"fire\": \"000\"},\"Cook Islands\":{\"police\": \"999\",\"ambulance\": \"998\",\"fire\": \"996\"},\"Fiji\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"French Polynesia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guam\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Kiribati\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Marshall Islands\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Micronesia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Nauru\":{\"police\": \"110\",\"ambulance\": \"111\",\"fire\": \"112\"},\"New Caledonia\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"New Zealand\":{\"police\": \"111\",\"ambulance\": \"111\",\"fire\": \"111\"},\"Palau\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Papua New Guinea\":{\"police\": \"112\",\"ambulance\": \"111\",\"fire\": \"110\"},\"Samoa\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Solomon Islands\":{\"police\": \"911 or 999\",\"ambulance\": \"911o or 999\",\"fire\": \"911 or 999\"},\"Tonga\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Tuvalu\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Vanuata\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Belize\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Clipperton Island\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Costa Rica\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Guatemala\":{\"police\": \"110\",\"ambulance\": \"128\",\"fire\": \"122\"},\"El Salvador\":{\"police\": \"911\",\"ambulance\": \"132\",\"fire\": \"913\"},\"Honduras\":{\"police\": \"911\",\"ambulance\": \"195\",\"fire\": \"198\"},\"Nicaragua\":{\"police\": \"118\",\"ambulance\": \"128\",\"fire\": \"115\"},\"Panama\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Antigua and Barbuda\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Anguilla\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Aruba\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"The Bahamas\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"British Virgin Islands\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Cayman Islands\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Cuba\":{\"police\": \"106\",\"ambulance\": \"104\",\"fire\": \"105\"},\"Curacao\":{\"police\": \"911\",\"ambulance\": \"912\",\"fire\": \"911\"},\"Dominica\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Grenada\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Guadeloupe\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Martinique\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Montserrat\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Navassa Island\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Saint Kitts and Nevis\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Saint Lucia\":{\"police\": \"911 or 999\",\"ambulance\": \"911 or 999\",\"fire\": \"911 or 999\"},\"Saint Vincent and the Grenadines\":{\"police\": \"911 or 999 or 112\",\"ambulance\": \"911 or 999 or 112\",\"fire\": \"911 or 999 or 112\"},\"Bonaire\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Dominican Republic\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Haiti\":{\"police\": \"114\",\"ambulance\": \"116\",\"fire\": \"115\"},\"Puerto Rico\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Trinidad and Tobago\":{\"police\": \"911 or 999\",\"ambulance\": \"811\",\"fire\": \"990\"},\"Jamaica\":{\"police\": \"119\",\"ambulance\": \"110\",\"fire\": \"110\"},\"Bermuda\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Canada\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Mexico\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Saint Pierre and Miquelon\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"United States of America\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Argentina\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Bolivia\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Brazil\":{\"police\": \"190\",\"ambulance\": \"192\",\"fire\": \"193\"},\"Chile\":{\"police\": \"133\",\"ambulance\": \"131\",\"fire\": \"132\"},\"Columbia\":{\"police\": \"123\",\"ambulance\": \"123\",\"fire\": \"123\"},\"Ecuador\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Falkland Islands\":{\"police\": \"112 or 999\",\"ambulance\": \"112 or 999\",\"fire\": \"112 or 999\"},\"French Guiana\":{\"police\": \"112\",\"ambulance\": \"112\",\"fire\": \"112\"},\"Guyana\":{\"police\": \"911\",\"ambulance\": \"913\",\"fire\": \"912\"},\"Paraguay\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Peru\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"South Georgia and the South Sandwich Islands\":{\"police\": \"999\",\"ambulance\": \"999\",\"fire\": \"999\"},\"Suriname\":{\"police\": \"115\",\"ambulance\": \"115\",\"fire\": \"115\"},\"Uruguay\":{\"police\": \"911\",\"ambulance\": \"911\",\"fire\": \"911\"},\"Venezuela\":{\"police\": \"911\",\"ambulance\": \"171\",\"fire\": \"171\"}}");
					JSONObject emergencyJson= (JSONObject) emergency;
					System.out.println("Desired ID: project_" + ids.get(j));
					System.out.println("Desired City: " + city.get(j).replace("\"", ""));
					System.out.println("Desired Country: " + country.get(j).replace("\"", ""));
					System.out.println("Desired Description: " + Description.replace("StringEscapeUtils.unescapeJava(sJava):", ""));
					System.out.println("Desired URL: " + url);
					System.out.println("Desired Emergency: " + emergencyJson.get(country.get(j).replace("\"", "").replace(" ", "_")));
					
					JSONObject numbers = (JSONObject) emergencyJson.get(country.get(j).replace("\"", "").replace(" ", "_"));
					ModelBuilder builderEmergency = new ModelBuilder();
					IRI emergencyInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "emergeny" + country.get(j).replace("\"", "").replace(" ", "_"));
					builderEmergency
					.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
					.subject(emergencyInstance)
				  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
				  		.add(RDFS.LABEL, "emergeny" + country.get(j).replace("\"", "").replace(" ", "_"))
				  		.add(RDF.TYPE,"Xr:EmergNumber")
				  		.add("Xr:hasPoliceNumber", numbers.get("police").toString().replace("\"", ""))
				  		.add("Xr:hasFireNumber", numbers.get("fire").toString().replace("\"", ""))
				  		.add("Xr:hasAmbulanceNumber", numbers.get("fire").toString().replace("\"", ""))
				  		.add("Xr:hasCountry", country.get(j).replace("\"", "").replace(" ", "_"));
					GraphDB.add2(builderEmergency.build());
					
					
					ModelBuilder builderGeneral = new ModelBuilder();
					IRI generalInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "general" + city.get(j).replace("\"", "").replace(" ", "_"));
					builderGeneral
					.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
					.subject(generalInstance)
				  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
				  		.add(RDFS.LABEL, "general" + city.get(j).replace("\"", "").replace(" ", "_"))
				  		.add(RDF.TYPE,"Xr:GeneralInfo")
				  		.add("Xr:hasDescription", Description.replace("StringEscapeUtils.unescapeJava(sJava):", ""))
				  		.add("Xr:hasURI", url)
				  		.add("Xr:hasLocation", "Xr:location" + city.get(j).replace("\"", "").replace(" ", "_"))
				  		.add("Xr:hasCountry", country.get(j).replace("\"", "").replace(" ", "_"));
					GraphDB.add2(builderGeneral.build());
					
					
					ModelBuilder builderLocation = new ModelBuilder();
					IRI locationInstance = Values.iri("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA", "location" + city.get(j).replace("\"", "").replace(" ", "_"));
					builderLocation
					.setNamespace("Xr","http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA")
					.subject(locationInstance)
				  		.add(RDF.TYPE, OWL.NAMEDINDIVIDUAL)
				  		.add(RDFS.LABEL, "location" + city.get(j).replace("\"", "").replace(" ", "_"))
				  		.add(RDF.TYPE,"Xr:Location")
				  		.add("Xr:hasGeolocation", city.get(j).replace("\"", "").replace(" ", "_"));
					GraphDB.add2(builderLocation.build());
					
					
			  }
		  }
		}
		catch(Exception e){
	        System.err.println(e.getCause());}
		
		return projectID;
	}

}