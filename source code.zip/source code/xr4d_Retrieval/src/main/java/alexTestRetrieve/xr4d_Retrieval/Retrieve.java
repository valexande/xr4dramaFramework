
package alexTestRetrieve.xr4d_Retrieval;


import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.UUID;

import org.eclipse.rdf4j.query.BindingSet;
import org.eclipse.rdf4j.query.TupleQuery;
import org.eclipse.rdf4j.query.TupleQueryResult;
import org.eclipse.rdf4j.repository.Repository;
import org.eclipse.rdf4j.repository.RepositoryConnection;
import org.eclipse.rdf4j.repository.manager.RemoteRepositoryManager;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;  
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Base64;
import java.util.UUID;
import org.eclipse.rdf4j.query.BindingSet;
import org.eclipse.rdf4j.query.TupleQuery;
import org.eclipse.rdf4j.query.TupleQueryResult;
import org.eclipse.rdf4j.repository.Repository;
import org.eclipse.rdf4j.repository.RepositoryConnection;
import org.eclipse.rdf4j.repository.manager.RemoteRepositoryManager;
import org.json.JSONArray;
import org.json.JSONObject;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import com.mongodb.*;
import org.bson.BsonDocument;
import org.bson.BsonInt64;
import org.bson.Document;
import org.bson.conversions.Bson;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import java.net.URLEncoder;
import org.slf4j.LoggerFactory;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import org.slf4j.LoggerFactory;
import org.json.JSONException;
import org.json.JSONString;


public class Retrieve {

    public static String queriesExecution(String input) {
        Gson gson = new Gson();

        JsonElement json = gson.fromJson(input, JsonElement.class);
        JsonObject jobject = json.getAsJsonObject();

        RemoteRepositoryManager repositoryManager = new RemoteRepositoryManager(Server.SERVER);
        repositoryManager.initialize();

        Repository testRepository = repositoryManager.getRepository(Server.REPOSITORY);


        String query = "PREFIX Xr: <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA>\r\n" +
                "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\r\n" +
                "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n" +
                "select distinct  ?observation ?type ?entity ?sit_label ?object ?ttime ?simmo ?category ?subcategory ?latitude ?longitude where { \r\n" +
               
                "    ?observation Xr:isConsistedIn ?project_id.\r\n" +
                "    ?observation Xr:hasObservationType ?type. \r\n" +
                "    ?observation Xr:hasCurrentTime ?ttime.\r\n" +
                "    OPTIONAL {?observation Xr:comesFromEntity ?entity.}\r\n" +
                "    OPTIONAL {?observation Xr:hasCurrentTime ?ttime. ?ioit Xr:featureOf ?observation. ?ioit Xr:hasTextualMetadata ?textual_meta. ?textual_meta Xr:hasLabel ?sit_label. FILTER (?ttime>\"" + jobject.get("first_timestamp").getAsString() + "\"^^xsd:dateTime && ?ttime<\"" + jobject.get("last_timestamp").getAsString() + "\"^^xsd:dateTime)}\r\n" +
                "    OPTIONAL {?observation Xr:hasInformationofInterest ?interest.?interest Xr:hasType ?object.}\r\n" +
                "	 OPTIONAL {?observation Xr:isRelatedWithSimmo ?simmo.\r\n}" +
                "    OPTIONAL {?observation Xr:hasCategory ?category.}\r\n" +
                "	 OPTIONAL {?observation Xr:hasSubCategory ?subcategory.}" +
                "    OPTIONAL {?observation Xr:hasCurrentTime ?ttime. ?ioit Xr:featureOf ?observation. ?ioit Xr:hasLocation ?location. ?location Xr:hasLatitude ?latitude. ?location Xr:hasLongitude ?longitude.}\r\n" +
                "    FILTER (?project_id=Xr:project_" + jobject.get("project_id").getAsString() + ")\r\n" +
                "} ";
        //System.out.println(query);//This shows the query if needed
        // Open a connection to the database
        RepositoryConnection testRepoConnection = testRepository.getConnection();
        TupleQuery tupleQuery = testRepoConnection.prepareTupleQuery(query);

        TupleQueryResult qresult = tupleQuery.evaluate();
        String uuid = UUID.randomUUID().toString().replace("-", "");
        JSONObject header = new JSONObject();
        //header creation
        header.put("id", uuid);
        header.put("first_timestamp", jobject.get("first_timestamp").getAsString());
        header.put("last_timestamp", jobject.get("last_timestamp").getAsString());
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(System.currentTimeMillis());
        

        // Conversion
        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        String time = sdf.format(date);
        header.put("created_at", time);
        
        JSONObject projectHelper = new JSONObject();
        JSONArray project = new JSONArray();
        
        //text analysis
        JSONArray text = new JSONArray();
        while (qresult.hasNext()) {
            BindingSet st = qresult.next();
            JSONObject textInstance = new JSONObject();
            JSONObject data = new JSONObject();
            JSONObject meta = new JSONObject();
            JSONObject location = new JSONObject();
            JSONArray coordinates = new JSONArray();
            //build meta text
            meta.put("project_id", jobject.get("project_id").getAsString());
            meta.put("sourceText", "");
            if (st.hasBinding("entity")){
            	meta.put("entity", st.getValue("entity").stringValue());
            }
            else {
            	meta.put("entity", "citizen_report");           	
            }
            if (st.hasBinding("simmo")){
            	meta.put("id", st.getValue("simmo").stringValue());
            }
            else {
            	meta.put("id", "No id");           	
            }
            
            location.put("inferred", "true");
            location.put("radius", "0");
            if (st.hasBinding("latitude") && st.hasBinding("longitude")) {
            	coordinates.put(st.getValue("latitude").stringValue());
            	coordinates.put(st.getValue("longitude").stringValue());
            }
            else {
            	coordinates.put("0");
            	coordinates.put("0");
            }
            location.put("coordinates", coordinates);
            meta.put("location", location);

          //build data text
            JSONObject wholeAffected = new JSONObject();
            JSONArray affected = new JSONArray();
            JSONArray situation = new JSONArray();
            data.put("type", st.getValue("type").stringValue());
            if (st.hasBinding("category") && st.hasBinding("subcategory")) {
            	data.put("category", st.getValue("category").stringValue());
            	data.put("subcategory", st.getValue("subcategory").stringValue());
            }
            else {
            	data.put("category", "Disaster Management");
            	data.put("subcategory", "Humans in Danger");
            }
            if (st.hasBinding("object")) {
            	affected.put(st.getValue("object").stringValue());	
            }
            else {
            	affected.put("");
            }
            wholeAffected.put("affected_objects", affected);
            if (st.hasBinding("sit_label")) {
            	wholeAffected.put("label", st.getValue("sit_label").stringValue());	
            }
            else {
            	wholeAffected.put("label", "");
            }
            situation.put(wholeAffected);
            data.put("situations", situation);
            
            //bind the json
            textInstance.put("data", data);
            textInstance.put("meta", meta);
            if (st.hasBinding("ttime")) {
            	textInstance.put("observationCreated", st.getValue("ttime").stringValue());	
            }
            else {
            	textInstance.put("observationCreated", "");
            }
            text.put(textInstance);
            
        }
        testRepoConnection.close();
        
        //start code for visuals
        RemoteRepositoryManager repositoryNewManager = new RemoteRepositoryManager(Server.SERVER);
        repositoryNewManager.initialize();

        Repository testNewRepository = repositoryNewManager.getRepository(Server.REPOSITORY);
        String queryNew = "PREFIX Xr: <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA>\r\n" +
                "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\r\n" +
                "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\r\n" +
                "select distinct ?multimedia ?vtime ?type ?observation ?people ?vehicle ?area ?outdoor ?s_id  ?simmo ?category ?subcategory where { \r\n" +
               
                "    OPTIONAL { ?observation Xr:isConsistedIn ?project_id.\r\n" +
                "    ?observation Xr:hasCurrentTime ?vtime. \r\n" +
                "    ?ioi ?p Xr:InformationOfInterest .\r\n" +
                "    ?ioi Xr:hasType ?type.\r\n" +
                "    ?ioi Xr:featureOfMetaInstance ?metadata.\r\n" +
                "    ?observation Xr:hasMultimedia ?multimedia.\r\n" +
                "	 ?multimedia Xr:hasSIMMORef ?simmo.\r\n" +
                "    ?metadata Xr:peopleInDanger ?people.\r\n" +
                "	 ?metadata Xr:vehicleInDanger ?vehicle.\r\n" +
                "    ?metadata Xr:hasEmergency ?em_type.\r\n" +
                
                "    ?metadata Xr:hasArea ?area.\r\n" +
                "	 ?metadata Xr:isOutdoor ?outdoor.\r\n" +
                "    ?metadata Xr:hasShotId ?s_id. \r\n" +
                "    ?metadata Xr:hasShotId ?s_id. \r\n" +
                "    FILTER (?vtime>\"" + jobject.get("first_timestamp").getAsString() + "\"^^xsd:dateTime && ?vtime<\"" + jobject.get("last_timestamp").getAsString() + "\"^^xsd:dateTime)}\r\n" +
                "    FILTER (?project_id=Xr:project_" + jobject.get("project_id").getAsString() + ")\r\n" +
                "} ";
        //System.out.println(queryNew);//This shows the query if needed
        // Open a connection to the database
        RepositoryConnection testNewRepoConnection = testNewRepository.getConnection();
        TupleQuery tupleNewQuery = testNewRepoConnection.prepareTupleQuery(queryNew);

        TupleQueryResult qNewresult = tupleNewQuery.evaluate();
        JSONArray visual = new JSONArray();
        JSONObject data = new JSONObject();
        JSONObject meta = new JSONObject();
        while (qNewresult.hasNext()) {
            BindingSet st = qNewresult.next();
            JSONObject visualInstance = new JSONObject();

            JSONObject location = new JSONObject();
            JSONArray coordinates = new JSONArray();
            //build meta visual
            meta.put("project_id", jobject.get("project_id").getAsString());
            meta.put("sourceText", "");
            if (st.hasBinding("entity")){
            	meta.put("entity", st.getValue("entity").stringValue());
            }
            else {
            	meta.put("entity", "citizen_report");           	
            }
            if (st.hasBinding("simmo")){
            	meta.put("id", st.getValue("simmo").stringValue());
            }
            else {
            	meta.put("id", "No id");           	
            }
            
           
            location.put("inferred", "true");
            location.put("radius", "0");
            if (st.hasBinding("latitude") && st.hasBinding("longitude")) {
            	coordinates.put(st.getValue("latitude").stringValue());
            	coordinates.put(st.getValue("longitude").stringValue());
            }
            else {
            	coordinates.put("0");
            	coordinates.put("0");
            }
            location.put("coordinates", coordinates);
            meta.put("location", location);
            
            if (st.hasBinding("vtime")){
            	meta.put("timestamp", st.getValue("vtime").stringValue());
            }
            else {
            	meta.put("timestamp", "No timestamp");           	
            }
           
            
            //build data visual
            JSONObject wholeAffected = new JSONObject();
            JSONArray affected = new JSONArray();
            JSONArray situation = new JSONArray();
            if (st.hasBinding("area")) {
            	data.put("area", st.getValue("area").stringValue());	
            }
            else {
            	affected.put("");
            }
        	
            if (st.hasBinding("type")) {
            	affected.put(st.getValue("type").stringValue());	
            }
            else {
            	affected.put("");
            }
            if (st.hasBinding("peopleInDanger")) {
            	affected.put(st.getValue("people").stringValue());	
            }
            else {
            	affected.put("");
            }
            if (st.hasBinding("vehiclesInDanger")) {
            	affected.put(st.getValue("vehicle").stringValue());	
            }
            else {
            	affected.put("");
            }
            wholeAffected.put("objectsFound", affected);
            if (st.hasBinding("em_type")) {
            	wholeAffected.put("type", st.getValue("em_type").stringValue());	
            }
            else {
            	wholeAffected.put("type", "");
            }
            situation.put(wholeAffected);
            data.put("situations", situation);
            //data.put("riverOvertop", "");
            //data.put("emergencyProb", 0);
            data.put("emergencyType", "flood");
            //data.put("areaProb", 0);
            //data.put("objectsInDanger", "");
            data.put("outdoor", "true");
            //data.put("objectsInDanger", "");
            //data.put("infraInDanger", "");
            //data.put("animalsInDanger", "");
            //bind the json
            
            
            //build data visual
            JSONObject innerJson = new JSONObject();
            JSONArray dataHelper = new JSONArray();
            
            dataHelper.put(data);
            innerJson.put("data", dataHelper);
            innerJson.put("meta", meta);
            
            visual.put(innerJson);
        }
        
       
        testNewRepoConnection.close();
        
        JSONArray visualFinal = new JSONArray();
        visualFinal.put(visual);
        projectHelper.put("project_id", jobject.get("project_id").getAsString());
        projectHelper.put("text", text);
        projectHelper.put("visual", visual);
        project.put(projectHelper);
        header.put("project", project);
        
        
        
        
        //finalJson
        JSONObject finalJson = new JSONObject();
        finalJson.put("header", header);
        System.out.println(finalJson);
        return finalJson.toString();
        //return "Endpoint Under construction"; 
    }

    public static String queriesExecutionForBackend(String input) {
        Gson gson = new Gson();

        JsonElement json = gson.fromJson(input, JsonElement.class);
        JsonObject jobject = json.getAsJsonObject();

        RemoteRepositoryManager repositoryManager = new RemoteRepositoryManager(Server.SERVER);
        repositoryManager.initialize();

        Repository testRepository = repositoryManager.getRepository(Server.REPOSITORY);
        JSONObject response = new JSONObject();


        String query = "PREFIX xR: <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA>\r\n" +
            "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\r\n" +
            "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\r\n" + 
            "select distinct ?v_simmo ?v_type ?multimedia ?vtime ?type ?prob ?observation ?people ?vehicle ?area ?ar_prob ?outdoor ?em_type ?em_prob ?s_id ?stime ?stress_result ?stress_level ?stress_lbl ?lbl ?uri ?t_label ?sit_label ?object ?ttime ?o_type ?ioit ?s_long ?s_lat ?text_simmo ?o_entity where { " +
            "	?observation a <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA#Observation> . \r\n" +
            "    ?observation xR:isConsistedIn ?project_id.\r\n" +
            "    OPTIONAL { #visuals \r\n" +
            "       ?observation xR:hasCurrentTime ?vtime.\r\n" +
            "       ?ioi ?p <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA#InformationOfInterest> .\r\n" +
            "    	?ioi xR:hasType ?type.\r\n" +
            "    	?ioi xR:hasProbability ?prob.\r\n" +
            "	    ?ioi xR:featureOfMetaInstance ?metadata." +
            "    	?observation xR:hasMultimedia ?multimedia.\r\n" +
            "        ?multimedia xR:hasSIMMORef ?v_simmo.\r\n" + 
            "		?multimedia rdf:type ?v_type.\r\n"+
            "		?metadata xR:peopleInDanger ?people.\r\n" +
            "       ?metadata xR:vehicleInDanger ?vehicle.\r\n" +
            "		?metadata xR:hasEmergency ?em_type.\r\n" +
            "		?metadata xR:hasEmergencyProb ?em_prob.\r\n" +
            "		?metadata xR:hasArea ?area.\r\n" +
            "		?metadata xR:hasAreaProb ?ar_prob.\r\n" +
            "		?metadata xR:isOutdoor ?outdoor.\r\n" +
            "       ?metadata xR:hasShotId ?s_id." +
            "       FILTER (?v_type!=<http://www.w3.org/2002/07/owl#NamedIndividual>)\r\n" + 
            ""+
            "       FILTER (?vtime>\"" + jobject.get("first_timestamp").getAsString() + "\"^^xsd:dateTime && ?vtime<\"" + jobject.get("last_timestamp").getAsString() + "\"^^xsd:dateTime)\r\n" +
            "    }\r\n" +
            "    OPTIONAL {   # sensors\r\n" +
            "       ?observation xR:hasTime ?stime.\r\n" +
            "    	?observation xR:hasResult ?stress_result.\r\n" +
            "    	?stress_result xR:hasStressLevel ?stress_level.\r\n" +
            "  ?stress_result xR:hasResultLabel ?stress_lbl." +
            "		?user a <http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA#FR> .\r\n" +
            "    	?user xR:included ?project_id.\r\n" +
            " ?user xR:related ?stress_result. " +
            "       ?user rdfs:label ?lbl." +
            "    	?user xR:hasFRLocation ?loc. \r\n" + 
            "    ?loc xR:hasLongitude ?s_long.\r\n" + 
            "    ?loc xR:hasLatitude ?s_lat.\r\n" +
            " ?loc xR:hasTime ?stime.\r\n"+
            "FILTER (?stime>\"" + jobject.get("first_timestamp").getAsString() + "\"^^xsd:dateTime && ?stime<\"" + jobject.get("last_timestamp").getAsString() + "\"^^xsd:dateTime)\r\n" +
            "    }\r\n" +

            " OPTIONAL { #text\r\n" +
            "        ?observation xR:hasCurrentTime ?ttime.\r\n" +
            "		?observation xR:isRelatedWithSimmo ?text_simmo."+
            "        ?ioit xR:featureOf ?observation.\r\n" +
            "        ?ioit xR:hasTextualMetadata ?textual_meta.\r\n" +
            "      \r\n" +
            "		 ?observation xR:hasObservationType ?o_type.\r\n" +
            "		OPTIONAL{ ?observation xR:comesFromEntity ?o_entity. }\r\n" +
            "		 ?textual_meta xR:hasLabel ?sit_label.\r\n" +
            "        OPTIONAL {\r\n" +
            "            ?ioit xR:hasLocation ?location.\r\n" +
            "        	?location xR:hasURI ?uri.\r\n" +
            "        }\r\n" +
            "        OPTIONAL {\r\n" +
            "         \r\n" +
            "        	?textual_meta xR:hasTextualRiskLabel ?t_label.\r\n" +
            "        }\r\n" +
            "        optional {\r\n" +
            "			?ioit xR:hasType ?object.\r\n" +
            "        }" +
            "    	FILTER (?ttime>\"" + jobject.get("first_timestamp").getAsString() + "\"^^xsd:dateTime && ?ttime<\"" + jobject.get("last_timestamp").getAsString() + "\"^^xsd:dateTime)\r\n" +
            "    }\r\n" +
            "    FILTER (?project_id=xR:Project_" + jobject.get("project_id").getAsString() + ")\r\n" +
            "} ";
        System.out.println(query);
        // Open a connection to the database
        RepositoryConnection testRepoConnection = testRepository.getConnection();

        TupleQuery tupleQuery = testRepoConnection.prepareTupleQuery(query);

        TupleQueryResult qresult = tupleQuery.evaluate();
        String uuid = UUID.randomUUID().toString().replace("-", "");
        JSONObject header = new JSONObject();
        header.put("id", uuid);
        header.put("first_timestamp", jobject.get("first_timestamp").getAsString());
        header.put("last_timestamp", jobject.get("last_timestamp").getAsString());

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Date date = new Date(System.currentTimeMillis());
        System.out.println(formatter.format(date));

        header.put("created_at", formatter.format(date).toString());

        JSONArray projects = new JSONArray();
        JSONArray visuals = new JSONArray();
        JSONArray stress_lvls = new JSONArray();
        JSONArray texts = new JSONArray();

        JSONObject visual = new JSONObject();
        JSONObject text = new JSONObject();
        JSONObject stress_lvl = new JSONObject();

        JSONObject situation = new JSONObject();

        JSONArray objects = new JSONArray();
        JSONObject object = new JSONObject();
        ArrayList < String > observations = new ArrayList < String > ();
        String last_observation = "null";
        String last_sit_label = "";
        while (qresult.hasNext()) {
            BindingSet st = qresult.next();

            // add visuals
            if (st.hasBinding("vtime") && st.hasBinding("type") && st.hasBinding("prob") && st.hasBinding("observation") && st.hasBinding("people") && st.hasBinding("vehicle") && st.hasBinding("s_id") &&
                st.hasBinding("em_type") && st.hasBinding("em_prob") && st.hasBinding("v_simmo") && st.hasBinding("v_type")) {

                if (last_observation.equals("text")) {

                    situation.put("objects", objects);

                    text.put("situation", situation);
                    texts.put(text);
                    objects = new JSONArray();

                }

                if (!observations.contains(st.getValue("observation").stringValue() + st.getValue("s_id"))) {
                    if (last_observation.equals("visual")) {
                        visual.put("objects", objects);
                        visuals.put(visual);
                        objects = new JSONArray();

                    }
                    observations.add(st.getValue("observation").stringValue() + st.getValue("s_id"));
                    visual = new JSONObject();
                    objects = new JSONArray();
                    visual.put("shotId", st.getValue("s_id").stringValue());
                    visual.put("timestamp", st.getValue("vtime").stringValue());
                    visual.put("peopleInDanger", st.getValue("people").stringValue());
                    visual.put("vehiclesInDanger", st.getValue("vehicle").stringValue());
                    visual.put("emergencyType", st.getValue("em_type").stringValue());
                    visual.put("emergencyProbability", st.getValue("em_prob").stringValue());
                    visual.put("area", st.getValue("area").stringValue());
                    visual.put("areaProbability", st.getValue("ar_prob").stringValue());
                    visual.put("outdoor", st.getValue("outdoor").stringValue());
                    visual.put("simmo", st.getValue("v_simmo").stringValue());
                    visual.put("entity", st.getValue("v_type").stringValue().replaceAll("http://www.semanticweb.org/ontologies/2021/5/InitialxR4DRAMA#", ""));


                }

                object = new JSONObject();
                object.put("type", st.getValue("type").stringValue());
                object.put("prob", Double.parseDouble(st.getValue("prob").stringValue()));
                objects.put(object);
                last_observation = "visual";
            }
            if (st.hasBinding("stime") && st.hasBinding("stress_level") && st.hasBinding("stress_lbl")&& st.hasBinding("s_long") && st.hasBinding("s_lat") && st.hasBinding("lbl")) {
                if (last_observation.equals("visual")) {
                    visual.put("objects", objects);
                    visuals.put(visual);
                    objects = new JSONArray();

                } else if (last_observation.equals("text")) {

                    situation.put("objects", objects);
                    text.put("situation", situation);
                    texts.put(text);
                    objects = new JSONArray();

                }
                stress_lvl = new JSONObject();
                stress_lvl.put("timestamp", st.getValue("stime").stringValue());
                stress_lvl.put("stress_level", st.getValue("stress_level").stringValue());
                stress_lvl.put("stress_label", st.getValue("stress_lbl").stringValue());
                stress_lvl.put("longitude", st.getValue("s_long").stringValue());
                stress_lvl.put("latitude", st.getValue("s_lat").stringValue());

                stress_lvl.put("user_id", st.getValue("lbl").stringValue().replace("FR_", "")); 
                stress_lvls.put(stress_lvl);

                last_observation = "stress_lvl";
            }
            if (st.hasBinding("ttime") && st.hasBinding("observation") && st.hasBinding("sit_label") && st.hasBinding("o_type")) {

                if (last_observation.equals("visual")) {
                    visual.put("objects", objects);
                    visuals.put(visual);
                    objects = new JSONArray();

                }

                if (!observations.contains(st.getValue("ioit").stringValue())) {
                    if (last_observation.equals("text")) {
                        if (!last_sit_label.equals(st.getValue("sit_label").stringValue())) {
                            situation.put("objects", objects);

                            text.put("situation", situation);
                            texts.put(text);

                            text = new JSONObject();
                            situation = new JSONObject();
                            objects = new JSONArray();
                        }
                    }
                    observations.add(st.getValue("ioit").stringValue());

                    text.put("timestamp", st.getValue("ttime").stringValue());

                    text.put("type", st.getValue("o_type").stringValue());
                    
                  
                    if (st.hasBinding("o_entity")) {
                        text.put("entity", st.getValue("o_entity").stringValue());
                    }
                    else {
                    	text.put("entity", "");
                    }
                             
                    if (st.hasBinding("text_simmo")) {
                    	text.put("simmo", st.getValue("text_simmo").stringValue());
                    }
                    
                    if (st.hasBinding("uri")) {
                        text.put("location", st.getValue("uri").stringValue());
                    }
                    else {
                    	text.put("location", "");
                    }
                    if (st.hasBinding("t_label")) {
                        text.put("risk_level", st.getValue("t_label").stringValue());
                    }
                    else {
                    	text.put("risk_level", "");
                    }
                }

                object = new JSONObject();
                if (!st.hasBinding("object")) {

                    situation.put("label", st.getValue("sit_label").stringValue());
                    situation.put("objects", objects);
                    last_sit_label = st.getValue("sit_label").stringValue();

                } else {

                    if (!hasValue(objects, "type", st.getValue("object").stringValue())) {

                        situation.put("label", st.getValue("sit_label").stringValue());

                        object.put("type", st.getValue("object").stringValue());
                        objects.put(object);
                        last_sit_label = st.getValue("sit_label").stringValue();
                    }
                }
                last_observation = "text";
            }
        }

        if (last_observation.equals("visual")) {
            visual.put("objects", objects);
            visuals.put(visual);
            objects = new JSONArray();

        } else if (last_observation.equals("text")) {
            situation.put("objects", objects);
            text.put("situation", situation);
            texts.put(text);
            objects = new JSONArray();


        }

        JSONObject project = new JSONObject();
        project.put("project_id", jobject.get("project_id").getAsString());
        project.put("visuals", visuals);
        project.put("stress_lvl", stress_lvls);
        project.put("text", texts);

        projects.put(project);
        header.put("project", projects);

        response.put("header", header);
        testRepoConnection.close();
        return response.toString();
    }

    public static boolean hasValue(JSONArray json, String key, String value) {
        for (int i = 0; i < json.length(); i++) { // iterate through the JsonArray
            // first I get the 'i' JsonElement as a JsonObject, then I get the key as a string and I compare it with the value
            if (json.getJSONObject(i).get(key).toString().equals(value)) return true;
        }
        return false;
    }
    
    public static String sendGetRequestStr(String url)
    {
        try{
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();

            //add request header
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", "Mozilla/5.0");
            con.setRequestProperty("api_key","8t8YKQegHHl4gMCPd5TF");

            int responseCode = con.getResponseCode();

            System.out.println("Sending 'GET' request to URL : " + url);
            System.out.println("Response Code : " + responseCode);

            if(responseCode!=200 && responseCode!=201)
                return "Error code returned: "+responseCode;

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine + "\n");
            }
            in.close();
            return response.toString();
        }
        catch(IOException io){
            System.out.println(io.getMessage());
            return "IO Exception: " + io.getMessage();
        }
    }

    public static String sendPostRequestRawStr(String url, String body, String format,
            String... creds)
			{
			try{
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			
			//add request header
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", "Mozilla/5.0");
			con.setRequestProperty("content-type",format);
			con.setRequestProperty("api_key","8t8YKQegHHl4gMCPd5TF");
			
			// credentials
			if(creds.length == 2){
			String encoded = Base64.getEncoder()
			.encodeToString((creds[0]+":"+creds[1]).getBytes(StandardCharsets.UTF_8));  //Java 8
			con.setRequestProperty("Authorization", "Basic "+encoded);
			}
			
			// Send post request
			System.out.println("Sending 'POST' request to URL : " + url);
			con.setDoOutput(true);
			
			
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(), "UTF-8"));
			bw.write(body);
			bw.flush();
			bw.close();
			
			
			int responseCode = con.getResponseCode();
			String responseText = con.getResponseMessage();
			
			
			System.out.println("Response Code : " + responseCode);
			
			//if(responseCode!=200 && responseCode!=409)
			if(responseCode!=200 && responseCode!=201 )
			return "Error code returned: "+responseCode;
			
			BufferedReader in = new BufferedReader(
			new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
			String inputLine;
			StringBuffer response = new StringBuffer();
			
			while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
			}
			in.close();
			System.out.println(response.toString());
			return response.toString();
			}
			catch(IOException io){
			System.out.println(io.getMessage());
			return "IO Exception: " + io.getMessage();
			}
			}

    public static String sendPutRequestRawStr(String url, String body, String format,
            String... creds)
			{
			try{
			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			
			//add request header
			con.setRequestMethod("PUT");
			con.setRequestProperty("User-Agent", "Mozilla/5.0");
			con.setRequestProperty("content-type",format);
			con.setRequestProperty("api_key","8t8YKQegHHl4gMCPd5TF");
			
			// credentials
			if(creds.length == 2){
			String encoded = Base64.getEncoder()
			.encodeToString((creds[0]+":"+creds[1]).getBytes(StandardCharsets.UTF_8));  //Java 8
			con.setRequestProperty("Authorization", "Basic "+encoded);
			}
			
			// Send post request
			System.out.println("Sending 'PUT' request to URL : " + url);
			con.setDoOutput(true);
			
			
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(con.getOutputStream(), "UTF-8"));
			bw.write(body);
			bw.flush();
			bw.close();
			
			
			int responseCode = con.getResponseCode();
			String responseText = con.getResponseMessage();
			
			
			System.out.println("Response Code : " + responseCode + " " + responseText);
			
			//if(responseCode!=200 && responseCode!=409)
			if(responseCode!=200 && responseCode!=201 )
			return "Error code returned: "+responseCode;
			
			BufferedReader in = new BufferedReader(
			new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
			String inputLine;
			StringBuffer response = new StringBuffer();
			
			while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
			}
			in.close();
			System.out.println(response.toString());
			return response.toString();
			}
			catch(IOException io){
			System.out.println(io.getMessage());
			return "IO Exception: " + io.getMessage();
			}
			}
    
    public static String queriesPOIvisual(String input) {
        Gson gson = new Gson();

        //code to create and send the json to the DSS
        JsonElement json = gson.fromJson(input, JsonElement.class);
        JsonObject jobject = json.getAsJsonObject();
        List<Integer> clusterIDHelper = new ArrayList<Integer>();
        String projectId = jobject.getAsJsonObject("header").get("project_id").toString().replace("\"", "");
        String titleGeneration = "";
  	    String descriptionGeneration = "";
    	if (projectId.equals("citizen")) {	
    		try {
    			   String response = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/");
    	    	   String[] parts = response.split("\"id\":");
    	    	   
    	    	   String[] latitudeList = response.split("\"latitude\":");
    	    	   String[] longitudeList = response.split("\"longitude\":");
    	    	   
    	    	   List<String> ids = new ArrayList<String>();
    	    	   for(int j = 1; j< parts.length; j++){
    	    		   ids.add(parts[j].split(",\"status\"")[0].toString());
    	    		   }
    	           
    	    	   List<String> latitudeListFinal = new ArrayList<String>();
    	    	   for(int j = 1; j < latitudeList.length; j++){
    	    		   latitudeListFinal.add(latitudeList[j].split(",\"longitude\":")[0].toString());
    	    		   }
    	    	   
    	    	   List<String> longitudeListFinal = new ArrayList<String>();
    	    	   for(int j = 1; j < longitudeList.length; j++){
    	    		   longitudeListFinal.add(longitudeList[j].split("},\"")[0].toString());
    	    		   }
    	    	  
    	    	   String[] startingDate = response.split("\"start_date\":");
    	    	   List<String> startDate = new ArrayList<String>();
    	    	   for(int j = 1; j < startingDate.length; j++){
    	    		   startDate.add(startingDate[j].split(",")[0].replace("\"", "").replace("}", "").replace("]", "").replace("[", "").replace("\n", ""));
    	    		   }
    	    	   String[] endingDate = response.split("\"end_date\":");
    	    	   List<String> endDate = new ArrayList<String>();
    	    	   for(int j = 1; j < endingDate.length; j++){
    	    		   endDate.add(endingDate[j].split(",")[0].replace("\"", "").replace("}", "").replace("]", "").replace("]", "").replace("\n", ""));
    	    		   }
    	    	   //create json for new pois
    	    	   
       			   double latitude = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("coordinate").getAsJsonArray().get(0).getAsDouble();
       			   double longitude = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("coordinate").getAsJsonArray().get(1).getAsDouble();


    	           //end here code for new pois json
    	           
    	           //procedure to find project ids
    	    	   List<Double> longitudeSE = new ArrayList<Double>();
    	    	   for(int j = 1; j < longitudeListFinal.size();  j = j + 2){
    	    		   double helper = 0;
    	    		   helper = Float.valueOf(longitudeListFinal.get(j));
    	    		   longitudeSE.add(helper);
    	    		   }
    	    	   
    	    	   List<Double> longitudeNW = new ArrayList<Double>();
    	    	   for(int j = 0; j < longitudeListFinal.size();  j = j + 2){
    	    		   double helper = 0;
    	    		   helper = Float.valueOf(longitudeListFinal.get(j));
    	    		   longitudeNW.add(helper);
    	    		   }
    	    	   
    	    	   List<Double> latitudeSE = new ArrayList<Double>();
    	    	   for(int j = 1; j < latitudeListFinal.size();  j = j + 2){
    	    		   double helper = 0;
    	    		   helper = Float.valueOf(latitudeListFinal.get(j));
    	    		   latitudeSE.add(helper);
    	    		   }
    	    	   
    	    	   List<Double> latitudeNW = new ArrayList<Double>();
    	    	   for(int j = 0; j < latitudeListFinal.size();  j = j + 2){
    	    		   double helper = 0;
    	    		   helper = Float.valueOf(latitudeListFinal.get(j));
    	    		   latitudeNW.add(helper);
    	    		   } 
    	    	   LocalDate date = LocalDate.now();
    	    	   for(int j = 0; j < longitudeSE.size(); j++) {
    	    		   double nwLat = 0;
    	    		   double seLat = 0;
    	    		   double nwLon = 0;
    	    		   double seLon = 0;
    	    		   nwLat = latitudeNW.get(j);
    	    		   seLat = latitudeSE.get(j);
    	    		   nwLon = longitudeNW.get(j);
    	    		   seLon = longitudeSE.get(j);

    	    	       
//    	    	       if(Integer.parseInt(startDate.get(j).split("-")[0]) <= Integer.parseInt(date.toString().split("-")[0]) && Integer.parseInt(date.toString().split("-")[0]) <= Integer.parseInt(endDate.get(j).split("-")[0])) {
//    	    	    	   if(Integer.parseInt(startDate.get(j).split("-")[1]) <= Integer.parseInt(date.toString().split("-")[1]) && Integer.parseInt(date.toString().split("-")[1]) <= Integer.parseInt(endDate.get(j).split("-")[1])) {
//    	    	    		   if(Integer.parseInt(startDate.get(j).split("-")[2]) <= Integer.parseInt(date.toString().split("-")[2]) && Integer.parseInt(date.toString().split("-")[2]) <= Integer.parseInt(endDate.get(j).split("-")[2])) {
//    	    	    			   System.out.println(ids.get(j));
//    	    	    		   }
//    	    	    	   }
//    	    	       }
    	    		   if( seLat <= latitude && latitude <= nwLat && nwLon <= longitude && longitude <= seLon ) {
    	    			   clusterIDHelper.add(Integer.valueOf(ids.get(j)));
    	    			}
    	    	   }
    		}
    		catch(Exception e){
    	        System.err.println(e.getCause());}
    	}
    	else {
    		
    		clusterIDHelper.add(Integer.valueOf(projectId));
    	}
        
        
    		System.out.println(clusterIDHelper);
    		//////////////////////////////////////////////////
    	   //find pois based on project ids
    	   List<String> idsPOISGeneration = new ArrayList<String>();
    	   List<String> categoryPOISGeneration = new ArrayList<String>();
    	   List<String> subcategoryPOISGeneration = new ArrayList<String>();
    	   List<String> latitudePOISGeneration = new ArrayList<String>();
    	   List<String> longitudePOISGeneration = new ArrayList<String>();

             
           double latitudeGeneration = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("coordinate").getAsJsonArray().get(0).getAsDouble();
           double longitudeGeneration = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("coordinate").getAsJsonArray().get(1).getAsDouble();
           String categoryConstGeneration = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("category").getAsString();
           String subcategoryConstGeneration  = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("subcategory").getAsString();

    	   
    	   for (int t = 0; t < clusterIDHelper.size(); t++) {
    		 String poisResponse = "";
 		     int indexMin = 0;
 		     indexMin = clusterIDHelper.get(t);
 		     poisResponse = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + indexMin + "/points-of-interest?current_user=%22" + jobject.getAsJsonObject("header").get("project_id").toString().replace("\"", "") + "%22&order=ASC&as_point=true");
 		     
 		     try{
 		     String[] poisIDs = poisResponse.split("\"id\":");
 		     
 		     for(int j = 1; j< poisIDs.length; j++){
 		    	idsPOISGeneration.add(indexMin + "-" + poisIDs[j].split(",\"category\"")[0].toString());
    		   }
 		     
 		     String[] poisCategory = poisResponse.split("\"category\":");
 		     for(int j = 1; j< poisCategory.length; j++){
 		    	categoryPOISGeneration.add(poisCategory[j].split(",\"subcategory\"")[0].toString());
    		   }

 		     String[] poisSubcategory = poisResponse.split("\"subcategory\":");
 		     for(int j = 1; j< poisSubcategory.length; j++){
 		    	subcategoryPOISGeneration.add(poisSubcategory[j].split(",\"username\"")[0].toString());
    		   }
 		     
 		     String[] lonPOIS = poisResponse.split("\"coordinates\"");
 		     for(int j = 1; j< lonPOIS.length; j++){
 		    	longitudePOISGeneration.add(lonPOIS[j].split(",")[0].toString().replace(":[", ""));
    		   }
 		     
 		     String[] latPOIS = poisResponse.split("\"coordinates\"");
 		     for(int j = 1; j< latPOIS.length; j++){
 		    	latitudePOISGeneration.add(latPOIS[j].split(",")[1].toString().replace(":[", "").replace("]}}", "").replace("]", ""));
    		   }
 		     }
 		     catch(Exception e){
 	               System.err.println(e.getCause());
 	          }
 		     }

 	   //Find the relative pois
        List<String> relativePOIGeneration = new ArrayList<String>();
 	   for(int j = 0; j < idsPOISGeneration.size(); j++) {
 		   double lat = 0;
 		   double lon = 0;
 		   String category = "";
 		   String subcategory = "";
 		   lat = Double.parseDouble(latitudePOISGeneration.get(j).replace("}", ""));
 		   lon = Double.parseDouble(longitudePOISGeneration.get(j).replace("}", ""));
 		   category = categoryPOISGeneration.get(j).replace("\"", "");
 		   subcategory = subcategoryPOISGeneration.get(j).replace("\"", "");
 		   if (Math.abs(latitudeGeneration - Math.abs(lat)) < 0.0005) {
 			   if (Math.abs(longitudeGeneration - Math.abs(lon)) < 0.0005) {
 				   if (category.equals(categoryConstGeneration)) {
 					   if (subcategory.split(",name")[0].equals(subcategoryConstGeneration)) {
 						  relativePOIGeneration.add(idsPOISGeneration.get(j));
 					   }
 				   }
 			   }
 		   }
 	   }
 	   System.out.println("Number of related pois for text generation: " + relativePOIGeneration);
 	   ///////////////////////////////////////////////////////////////////////////////////
 	   
 	   
 	   
 	   
    	String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
        String allImage = "";
        String allProject = "";
        ArrayList<String> descriptionPOI = new ArrayList<String>();
    	for (int id = 0; id<clusterIDHelper.size(); id++) {
        
        JSONObject jsonDSS = new JSONObject();
        jsonDSS.put("type", "Visual");
        jsonDSS.put("id", clusterIDHelper.get(id).toString().replace("\"", ""));
        

        
        JSONArray shotInfo = new JSONArray();
        for (int i =0; i < jobject.getAsJsonArray("shotInfo").size(); i++) {
        	JSONObject shot = new JSONObject();
        	int shotID = Integer.parseInt(jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("shotIdx").toString());
        	double people = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("peopleInDanger").getAsDouble();
        	double vehicle = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("vehiclesInDanger").getAsDouble();
        	float probArea = Float.parseFloat(jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("areaProb").toString());
        	double animals = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("animalsInDanger").getAsDouble();//
        	String emergencyType = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("emergencyType").toString().replace("\"", "");//
        	float probType = Float.parseFloat(jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("emergencyProb").toString());//
        	String outdoor = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("outdoor").toString().replace("\"", "");
        	String infra = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("infraInDanger").toString().replace("\"", "");
        	String river = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("riverOvertop").toString().replace("\"", "");
        	String objDanger = jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("objectsInDanger").toString().replace("\"", "");
        	
        	shot.put("shotIdx", shotID);
        	shot.put("peopleInDanger", people);
        	shot.put("vehiclesInDanger", vehicle);
        	shot.put("area", jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().get("area").toString().replace("\"", ""));
        	shot.put("areaProb", probArea);
        	shot.put("animalsInDanger", animals);
        	shot.put("emergencyType", emergencyType);
        	shot.put("outdoor", outdoor);
        	shot.put("riverOvertop", river);
        	shot.put("infraInDanger", infra);
        	shot.put("objectsInDanger", objDanger);
        	shot.put("emergencyProb", probType);
        	JSONArray objectsAll = new JSONArray();
        	for (int j=0; j < jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().getAsJsonArray("objectsFound").size(); j++) {
        		JSONObject objectSolo = new JSONObject();
        		float probObject = Float.parseFloat(jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().getAsJsonArray("objectsFound").get(j).getAsJsonObject().get("probability").toString());
        		objectSolo.put("type", jobject.getAsJsonArray("shotInfo").get(i).getAsJsonObject().getAsJsonArray("objectsFound").get(j).getAsJsonObject().get("type").toString().replace("\"", ""));
        		objectSolo.put("probability", probObject);
        		objectsAll.put(objectSolo);
        	}
        	shot.put("objectsFound", objectsAll);
        	shotInfo.put(shot);
        	
        }
        jsonDSS.put("shotInfo", shotInfo);
             
        
        ///text for TG
        ArrayList<JSONArray> listOfArrays = new ArrayList<JSONArray>();
        ArrayList<String> listOfStrings = new ArrayList<String>();
        	for (int tg = 0; tg < relativePOIGeneration.size(); tg++) {   
	        try {
    	   		String poisGeneration = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + relativePOIGeneration.get(tg).split("-")[0] + "/points-of-interest/" + relativePOIGeneration.get(tg).split("-")[1] + "?current_user=%22" + jobject.getAsJsonObject("header").get("project_id").toString().replace("\"", "") + "%22&order=ASC&as_point=true");
    	   		Gson gsonNew = new Gson();
    	        JsonElement jsonNew = gsonNew.fromJson(poisGeneration, JsonElement.class);
    	        JsonObject jobjectNew = jsonNew.getAsJsonObject();
    	        
    	         JSONObject metaText = new JSONObject();
    	         JSONObject dataText = new JSONObject();
    	         JSONObject innerText = new JSONObject();
    	         JSONArray outerText = new JSONArray();
    	         dataText.put("category", jobjectNew.get("category").toString().replace("\"", ""));
    	         dataText.put("subcategory", jobjectNew.get("subcategory").toString().replace("\"", ""));
    	         dataText.put("type", "incident");
    	         dataText.put("timeReference", JSONObject.NULL);
    	         JSONArray tagger = new JSONArray();
    	         dataText.put("tags", tagger);
    	         JSONObject situations = new JSONObject();
    	         JSONArray agents = new JSONArray();
    	         situations.put("agents", agents);
    	         situations.put("label", jobjectNew.get("attributes").getAsJsonObject().get("label").toString().replace("\"", ""));
    	         situations.put("affected_objects", jobjectNew.get("attributes").getAsJsonObject().get("affected_objects").toString().replace("\"[", "").replace("]\"", "").split(","));
    	         JSONArray situationsWrapper = new JSONArray();
    	         situationsWrapper.put(situations);
    	         dataText.put("situations", situationsWrapper);
    	         innerText.put("data", dataText);
    	         innerText.put("observationCreated", JSONObject.NULL);
    	         
    	         metaText.put("type", JSONObject.NULL);
    	         metaText.put("date", JSONObject.NULL);
    	         metaText.put("times", JSONObject.NULL);
    	         metaText.put("id", jobjectNew.get("id"));
    	         metaText.put("entity", "citizen_report");
    	         metaText.put("sourceType", JSONObject.NULL);
    	         metaText.put("timestamp", JSONObject.NULL);
    	         metaText.put("sourceText", jobjectNew.get("description").toString().replace("\\n", "\n").replace("\"", ""));
    	         metaText.put("project_id", relativePOIGeneration.get(tg).split("-")[0]);
    	         JSONObject location = new JSONObject();
    	         location.put("country", JSONObject.NULL);
    	         location.put("city", JSONObject.NULL);
    	         location.put("bbox", JSONObject.NULL);
    	         location.put("inferred", false);
    	         location.put("unifiedText", JSONObject.NULL);
    	         location.put("adress", JSONObject.NULL);
    	         location.put("radius", 0.0);
    	         JSONArray coordinates = new JSONArray();
    	         coordinates.put(jobjectNew.get("geometry").getAsJsonObject().get("coordinates").toString().replace("\"", "").replace("\"[", "").replace("]\"", ""));
    	         location.put("coordinates", jobjectNew.get("geometry").getAsJsonObject().get("coordinates").toString().replace("[", "").replace("]", "").split(","));
    	         metaText.put("location", location);
    	         innerText.put("meta", metaText);
    	         outerText.put(innerText);
    	         listOfArrays.add(outerText);
    	         listOfStrings.add(relativePOIGeneration.get(tg).toString());
	        }catch(Exception e){
		        System.err.println(e.getCause());
		    }
	    }
        ///end text for TG
        System.out.println("Textual part length: " + listOfArrays.size());	
        System.out.println("Project - POI id length: " + listOfStrings.size());	
        
        
        for (int t = 0; t < listOfArrays.size(); t++) {
	        JSONObject projectInfo = new JSONObject();
	        try {
	 	    //new code for text generation
	         JSONObject metaTG = new JSONObject();
	         JSONObject locationTG = new JSONObject();
	         
	         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	         Date date = new Date(System.currentTimeMillis());
	         SimpleDateFormat sdf;
	         sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
	         sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
	         String time = sdf.format(date);
	         
	 	     projectInfo.put("data",shotInfo);
	 	     metaTG.put("id", "");
	 	     metaTG.put("entity", projectId);
	 	     metaTG.put("project_id", projectId);
	 	     metaTG.put("timeStamp", time);
	 	     metaTG.put("sourceText", "");
	 	     locationTG.put("radius", 0.0);
	 	     locationTG.put("inferred", false);
	 	     locationTG.put("coordinates", jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("coordinate").getAsJsonArray());
	 	     metaTG.put("location", locationTG);
	 	     projectInfo.put("meta",metaTG);
	 	     
	 	    JSONArray helperInfo = new JSONArray();
	 	    helperInfo.put(projectInfo);
	 	    
	 	    
	 	    JSONObject projectInner = new JSONObject();
	 	    projectInner.put("project_id", projectId);
	 	    projectInner.put("visual", helperInfo);
	 	    JSONArray textHelper = new JSONArray();
	 	    JSONArray stress_lvl = new JSONArray();
	 	    projectInner.put("text", listOfArrays.get(t));
	 	    projectInner.put("stress_lvl", stress_lvl);
	 	    JSONArray projectOuter = new JSONArray();
	 	    projectOuter.put(projectInner);
	 	    
	        
	 	    JSONObject header = new JSONObject();
	 	    
	 	    header.put("id", "");
	 	    header.put("created_at", time);
	 	    header.put("first_timestamp", time);
	 	    header.put("last_timestamp", time);
	 	    header.put("project", projectOuter);
	 	    JSONObject tgFinal = new JSONObject();
	 	    tgFinal.put("header", header);
	 	    System.out.println("Textual Generation JSON: " + tgFinal);
	 	    
			 String idGeneration = "";
			
			 idGeneration = "https://xr4drama.upf.edu/xr4drama-services/api/nlg/generatePOI";
			 String responseTG = sendPostRequestRawStr(idGeneration, tgFinal.toString(), "application/json");
	       	 JsonElement jsonTG = gson.fromJson(responseTG, JsonElement.class);
	       	 JsonObject helperTG = jsonTG.getAsJsonObject();
	       	 
	         System.out.println(helperTG.get("data").getAsJsonObject().get("description").toString());
	         System.out.println(helperTG.get("data").getAsJsonObject().get("title").toString());
	         
	  	     titleGeneration = helperTG.get("data").getAsJsonObject().get("title").toString();
	  	     descriptionGeneration = helperTG.get("data").getAsJsonObject().get("description").toString();
	      	 
	  	     descriptionPOI.add(descriptionGeneration.toString().replace("\"", "") + "000" + titleGeneration.toString().replace("\"", "") + "000" + listOfStrings.toString().replace("\"", "").toString().replace("[", "").toString().replace("]", "").toString().split("-")[1]);
		    } catch(Exception e){
		        System.err.println(e.getCause());
		    }
	 	    //end code for text generation  
        }
        System.out.println("The descriptions: " + descriptionPOI);
        
        ///new code severity///
        JSONObject objectDSSDanger = new JSONObject();
        try{
    	   String responseDanger = "";
       	   responseDanger = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" +  clusterIDHelper.get(id).toString().replace("\"", "") + "/danger-zones");
       	   JsonElement jsonDanger = gson.fromJson(responseDanger, JsonElement.class);
       	   for (int i=0; i < jsonDanger.getAsJsonArray().size();i++) {
       		   JsonObject danger = jsonDanger.getAsJsonArray().get(i).getAsJsonObject();
	   		   double nwLatDanger = danger.get("location_nw").getAsJsonObject().get("latitude").getAsDouble();
	   		   double seLatDanger = danger.get("location_se").getAsJsonObject().get("latitude").getAsDouble();
	   		   double nwLonDanger = danger.get("location_nw").getAsJsonObject().get("longitude").getAsDouble();
	   		   double seLonDanger = danger.get("location_se").getAsJsonObject().get("longitude").getAsDouble();
	   		   
   			   double latitude = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("coordinate").getAsJsonArray().get(0).getAsDouble();
   			   double longitude = jobject.get("shotInfo").getAsJsonArray().get(0).getAsJsonObject().get("coordinate").getAsJsonArray().get(1).getAsDouble();
	   		   if( seLatDanger <= latitude && latitude <= nwLatDanger && nwLonDanger <= longitude && longitude <= seLonDanger ) {
	   			   if (danger.get("description").toString().contains(":")) {
	   			   objectDSSDanger.put("severity", danger.get("description").toString().replace("\"", "").split(": ")[1]);
	   			   }
	   			   else {
	   				objectDSSDanger.put("severity", danger.get("description").toString().replace("\"", ""));
	   			   }
	   			   objectDSSDanger.put("created_at", danger.get("created_at").toString().replace("\"", ""));
	   			   objectDSSDanger.put("id",  clusterIDHelper.get(id).toString().replace("\"", ""));
	   			   objectDSSDanger.put("latitude", latitude);
	   			   objectDSSDanger.put("longitude", longitude);
       		   }
       	   }
	    } catch(Exception e){
	        System.err.println(e.getCause());
	    }
	   jsonDSS.put("dangerInfo", objectDSSDanger);
	   ///new code severity score////
       
	   System.out.println(jsonDSS);
	   System.out.println(objectDSSDanger);
	   if (jsonDSS.has("id") ) {
 	   try{

		   ConnectionString connectionString = new ConnectionString("mongodb://xr4d_dss_user:x38vC&26@160.40.53.24:27017/?authSource=XR4D_DSS");
    	   MongoClientSettings settings = MongoClientSettings.builder()
    	           .applyConnectionString(connectionString)
    	           .build();
    	   MongoClient mongoClient = MongoClients.create(settings);
    	   MongoDatabase database = mongoClient.getDatabase("XR4D_DSS");
    	   MongoCollection<Document> toys = database.getCollection("cappedCollection");
    	   Document doc = Document.parse(jsonDSS.toString());
    	   toys.insertOne(doc);
  
    	   
    	   LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
    	   Logger rootLogger = loggerContext.getLogger("org.mongodb.driver");
    	   rootLogger.setLevel(Level.OFF);
    	   mongoClient.close();
    	 
   
       } catch(Exception e){
           System.err.println(e.getCause());
       }
	   }
 	  
    	}
 	   //code for poi creation or update
 	  
 	  int flag = 0;
   	  String user = "";
   	  user = jobject.getAsJsonObject("header").get("project_id").toString().replace("\"", "");
 	  for (int i =0; i < jobject.getAsJsonArray("shotInfo").size(); i++) {

   	   
   	   String response = "";
   	   response = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/");
   	   
   	   String[] parts = response.split("\"id\":");
   	   String[] latitudeList = response.split("\"latitude\":");
   	   String[] longitudeList = response.split("\"longitude\":");
   	   
   	   List<String> ids = new ArrayList<String>();
   	   for(int j = 1; j< parts.length; j++){
   		   ids.add(parts[j].split(",\"status\"")[0].toString());
   		   }
          
   	   List<String> latitudeListFinal = new ArrayList<String>();
   	   for(int j = 1; j < latitudeList.length; j++){
   		   latitudeListFinal.add(latitudeList[j].split(",\"longitude\":")[0].toString());
   		   }
   	   
   	   List<String> longitudeListFinal = new ArrayList<String>();
   	   for(int j = 1; j < longitudeList.length; j++){
   		   longitudeListFinal.add(longitudeList[j].split("},\"")[0].toString());
   		   }
   	   
   	   
   	      	   
   	   //create json for new pois
   	   	  double longitude = 0.0;
          double latitude = 0.0;
          double vehiclesInDanger = 0.0;
          double peopleInDanger = 0.0;
          String categoryConst = "";
          String subcategoryConst = "";
          String emergencyType = "";
          String outdoor = "";
          String animalsInDanger = "";
          String area = "";
          String riverOvertop = "";
          String infrastructure = "";
          String objectDanger = "";
          
          latitude = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("coordinate").getAsJsonArray().get(0).getAsDouble();
          longitude = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("coordinate").getAsJsonArray().get(1).getAsDouble();
          categoryConst = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("category").getAsString();
          subcategoryConst  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("subcategory").getAsString();
          outdoor  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("outdoor").getAsString();
          emergencyType  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("emergencyType").getAsString();
          peopleInDanger  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("peopleInDanger").getAsDouble();
          vehiclesInDanger  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("vehiclesInDanger").getAsDouble();
          animalsInDanger  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("animalsInDanger").getAsString();
          area  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("area").getAsString();
          riverOvertop  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("riverOvertop").getAsString();
          infrastructure  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("infraInDanger").getAsJsonArray().toString().replace("\"","");
          objectDanger  = jobject.get("shotInfo").getAsJsonArray().get(i).getAsJsonObject().get("objectsInDanger").getAsJsonArray().toString().replace("\"","");
          
 	  
	       //end here code for new pois json
	          
	       //procedure to find project ids
	   	   List<Double> longitudeSE = new ArrayList<Double>();
	   	   for(int j = 1; j < longitudeListFinal.size();  j = j + 2){
	   		   double helper = 0;
	   		   helper = Float.valueOf(longitudeListFinal.get(j));
	   		   longitudeSE.add(helper);
	   		   }
	   	   
	   	   List<Double> longitudeNW = new ArrayList<Double>();
	   	   for(int j = 0; j < longitudeListFinal.size();  j = j + 2){
	   		   double helper = 0;
	   		   helper = Float.valueOf(longitudeListFinal.get(j));
	   		   longitudeNW.add(helper);
	   		   }
	   	   
	   	   List<Double> latitudeSE = new ArrayList<Double>();
	   	   for(int j = 1; j < latitudeListFinal.size();  j = j + 2){
	   		   double helper = 0;
	   		   helper = Float.valueOf(latitudeListFinal.get(j));
	   		   latitudeSE.add(helper);
	   		   }
	   	   
	   	   List<Double> latitudeNW = new ArrayList<Double>();
	   	   for(int j = 0; j < latitudeListFinal.size();  j = j + 2){
	   		   double helper = 0;
	   		   helper = Float.valueOf(latitudeListFinal.get(j));
	   		   latitudeNW.add(helper);
	   		   } 
	   	  
	          
	          List<Integer> clusterIDs = new ArrayList<Integer>();
	   	   for(int j = 0; j < longitudeSE.size(); j++) {
	   		   double nwLat = 0;
	   		   double seLat = 0;
	   		   double nwLon = 0;
	   		   double seLon = 0;
	   		   nwLat = latitudeNW.get(j);
	   		   seLat = latitudeSE.get(j);
	   		   nwLon = longitudeNW.get(j);
	   		   seLon = longitudeSE.get(j);
	   		   if( seLat <= latitude && latitude <= nwLat && nwLon <= longitude && longitude <= seLon ) {
	   			   clusterIDs.add(Integer.valueOf(ids.get(j)));
	   			}
	   	   }//for
	   	   //end finding project ids
          System.out.println(clusterIDs.size());
          
          
          
   	   //find pois based on project ids
   	   List<String> idsPOIS = new ArrayList<String>();
   	   List<String> categoryPOIS = new ArrayList<String>();
   	   List<String> subcategoryPOIS = new ArrayList<String>();
   	   List<String> latitudePOIS = new ArrayList<String>();
   	   List<String> longitudePOIS = new ArrayList<String>();
   	   System.out.println(clusterIDs.size());
   	   
   	   for (int t = 0; t < clusterIDs.size(); t++) {
   		 String poisResponse = "";
		     int indexMin = 0;
		     indexMin = clusterIDs.get(t);
		     poisResponse = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + indexMin + "/points-of-interest?current_user=%22" + user.replace("\"", "") + "%22&order=ASC&as_point=true");
		     
		     try{
		     String[] poisIDs = poisResponse.split("\"id\":");
		     
		     for(int j = 1; j< poisIDs.length; j++){
		    	 idsPOIS.add(indexMin + "-" + poisIDs[j].split(",\"category\"")[0].toString());
   		   }
		     
		     String[] poisCategory = poisResponse.split("\"category\":");
		     for(int j = 1; j< poisCategory.length; j++){
		    	 categoryPOIS.add(poisCategory[j].split(",\"subcategory\"")[0].toString());
   		   }

		     String[] poisSubcategory = poisResponse.split("\"subcategory\":");
		     for(int j = 1; j< poisSubcategory.length; j++){
		    	 subcategoryPOIS.add(poisSubcategory[j].split(",\"username\"")[0].toString());
   		   }
		     
		     String[] lonPOIS = poisResponse.split("\"coordinates\"");
		     for(int j = 1; j< lonPOIS.length; j++){
		    	 longitudePOIS.add(lonPOIS[j].split(",")[0].toString().replace(":[", ""));
   		   }
		     
		     String[] latPOIS = poisResponse.split("\"coordinates\"");
		     for(int j = 1; j< latPOIS.length; j++){
		    	 latitudePOIS.add(latPOIS[j].split(",")[1].toString().replace(":[", "").replace("]}}", "").replace("]", ""));
   		   }
		     }
		     catch(Exception e){
	               System.err.println(e.getCause());
	          }
		     }

	   //Find the relative pois
       List<String> relativePOI = new ArrayList<String>();
	   for(int j = 0; j < idsPOIS.size(); j++) {
		   double lat = 0;
		   double lon = 0;
		   String category = "";
		   String subcategory = "";
		   lat = Double.parseDouble(latitudePOIS.get(j).replace("}", ""));
		   lon = Double.parseDouble(longitudePOIS.get(j).replace("}", ""));
		   category = categoryPOIS.get(j).replace("\"", "");
		   subcategory = subcategoryPOIS.get(j).replace("\"", "");
		   if (Math.abs(latitude - Math.abs(lat)) < 0.0005) {
			   if (Math.abs(longitude - Math.abs(lon)) < 0.0005) {
				   if (category.equals(categoryConst)) {
					   if (subcategory.split(",name")[0].equals(subcategoryConst)) {
						   relativePOI.add(idsPOIS.get(j));
					   }
				   }
			   }
		   }
	   }
	   
	   
	   
	   
	   
	   System.out.println(relativePOI.size());
          
	   //ends find relative pois
	   //relativePOI.clear();
	   String imagePOI = "";
	   if (relativePOI.size() > 0) {
		   List<String> allIDS = new ArrayList<String>();
		   for (int j = 0; j < relativePOI.size(); j++) {//change this later to relativePOI list
	    	   
	           JSONObject attributeInstance = new JSONObject();
	           JSONObject attribute = new JSONObject();
	           String pep =String.valueOf(peopleInDanger); 
	           attribute.put("peopleInDanger", pep);
	           String veh =String.valueOf(vehiclesInDanger); 
	           attribute.put("vehiclesInDanger", veh);
	           attribute.put("animalsInDanger", animalsInDanger);
	           attribute.put("outdoor", outdoor);
	           attribute.put("infraInDanger", infrastructure);
	           attribute.put("objectsInDanger", objectDanger);
	           attribute.put("riverOvertop", riverOvertop);
	           attribute.put("area", area);
	           attribute.put("emergencyType", emergencyType);
	           attributeInstance.put("attributes", attribute);
	           attributeInstance.put("category",categoryConst);
	           attributeInstance.put("subcategory", subcategoryConst);
	           
	           
	           String descriptionFinal = "";
	           String titleFinal = "";
	           for (int t=0; t < descriptionPOI.size(); t++) {
	        	    if (relativePOI.get(j).split("-")[1].toString().equals(descriptionPOI.get(t).toString().replace("\"", "").split("000")[2].toString())){
	        	    	descriptionFinal = descriptionPOI.get(t).toString().replace("\"", "").split("000")[0].toString();
	        	    	titleFinal = descriptionPOI.get(t).toString().replace("\"", "").split("000")[1].toString();
	        	    }
	           }
	           if (descriptionFinal.equals("")) {
	        	   attributeInstance.put("description", "");
	           }
	           else{
	        	   attributeInstance.put("description", descriptionFinal.replace("\"", "").replace("\\n", "\n"));
	           }
	           if (titleFinal.equals("")) {
	        	   attributeInstance.put("name", "");
	           }
	           else{
	        	   attributeInstance.put("name", titleFinal.replace("\"", "").replace("\\n", "\n"));
	           }
	           
	           JSONObject geometryObject = new JSONObject();
	           geometryObject.put("type","Point");
	           JSONArray coordinatesArr = new JSONArray();
	           coordinatesArr.put(longitude);//the above are the theoretically correct commands
	           coordinatesArr.put(latitude);
	       
	           geometryObject.put("coordinates",coordinatesArr);
	           attributeInstance.put("geometry",geometryObject);
	           
			   String idPOI = "";
			   System.out.println(attributeInstance);
			   idPOI = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + relativePOI.get(j).split("-")[0].toString() + "/points-of-interest/" + relativePOI.get(j).split("-")[1].toString() + "?current_user=citizen";
			   System.out.println(idPOI);
			   String answerUpdate = sendPutRequestRawStr(idPOI, attributeInstance.toString(), "application/json");
			   allIDS.add(relativePOI.get(j).split("-")[1].toString());
			   //all attributes can be created
			   if (answerUpdate.contains("404")) {

				   JSONObject people = new JSONObject();
				   JSONObject vehicles = new JSONObject();
				   JSONObject animals = new JSONObject();
				   JSONObject out = new JSONObject();
				   JSONObject infra = new JSONObject();
				   JSONObject obj = new JSONObject();
				   JSONObject river = new JSONObject();
				   JSONObject location = new JSONObject();
				   JSONObject emerg = new JSONObject();
				   
				   people.put("peopleInDanger", pep);
				   vehicles.put("vehiclesInDanger", veh);
				   animals.put("animalsInDanger", animalsInDanger);
				   out.put("outdoor", outdoor);
				   infra.put("infraInDanger", infrastructure);
				   obj.put("objectsInDanger", objectDanger);
				   river.put("riverOvertop", riverOvertop);
				   location.put("area", area);
				   emerg.put("emergencyType", emergencyType);
				   
				   String idPOINew = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + relativePOI.get(j).split("-")[0].toString() + "/points-of-interest/" + relativePOI.get(j).split("-")[1].toString() + "/attributes?current_user=citizen";
				   sendPostRequestRawStr(idPOINew, people.toString(), "application/json");//ok
				   sendPostRequestRawStr(idPOINew, vehicles.toString(), "application/json");//ok
				   sendPostRequestRawStr(idPOINew, animals.toString(), "application/json");//ok
				   sendPostRequestRawStr(idPOINew, out.toString(), "application/json");
				   sendPostRequestRawStr(idPOINew, infra.toString(), "application/json");//ok
				   sendPostRequestRawStr(idPOINew, obj.toString(), "application/json");
				   sendPostRequestRawStr(idPOINew, river.toString(), "application/json");
				   sendPostRequestRawStr(idPOINew, location.toString(), "application/json");
				   sendPostRequestRawStr(idPOINew, emerg.toString(), "application/json");
			   }
		   }
		   
		   imagePOI = allIDS.toString();
	   }
	   else {//create new pois
		   //code for updating a poi

           JSONObject jsonObject = new JSONObject();
           jsonObject.put("category",categoryConst);
           jsonObject.put("subcategory", subcategoryConst);
           jsonObject.put("current_user", user.replace("\"", ""));
           jsonObject.put("name", "Citizen generated POI " + timeStamp);
           JSONObject geometryObject = new JSONObject();
           geometryObject.put("type","Point");
           JSONArray coordinatesArr = new JSONArray();
           coordinatesArr.put(longitude);//the above are the theoretically correct commands
           coordinatesArr.put(latitude);
       
           geometryObject.put("coordinates",coordinatesArr);
           jsonObject.put("geometry",geometryObject);
           //visual extra
           JSONObject jsonAttribute = new JSONObject();
           String pep =String.valueOf(peopleInDanger);
           String veh =String.valueOf(vehiclesInDanger);
           jsonAttribute.put("peopleInDanger", pep);
           jsonAttribute.put("vehiclesInDanger", veh);
           jsonAttribute.put("animalsInDanger", animalsInDanger);
           jsonAttribute.put("outdoor", outdoor);
           jsonAttribute.put("infraInDanger", infrastructure);
           jsonAttribute.put("objectsInDanger", objectDanger);
           jsonAttribute.put("riverOvertop", riverOvertop);
           jsonAttribute.put("area", area);
           jsonAttribute.put("emergencyType", emergencyType);
           
           jsonObject.put("attributes",jsonAttribute);
           //
           String descriptionFinal = descriptionPOI.get(0).toString().replace("\"", "").split("000")[1].toString();
           String titleFinal = descriptionPOI.get(1).toString().replace("\"", "").split("000")[0].toString();
           
           if (descriptionFinal.equals("")) {
        	   jsonObject.put("description", "");
           }
           else{
        	   jsonObject.put("description", descriptionFinal.replace("\"", "").replace("\\n", "\n"));
           }
           if (titleFinal.equals("")) {
        	   jsonObject.put("name", "");
           }
           else{
        	   jsonObject.put("name", titleFinal.replace("\"", "").replace("\\n", "\n"));
           }
           String jsonBody = jsonObject.toString();
           
           List<String> allIDS = new ArrayList<String>();
           for (int t = 0; t < clusterIDs.size(); t++) {
        	   String id = "";
           	   int indexMinNew = 0;
           	   indexMinNew = clusterIDs.get(t);
           	   System.out.println(jsonBody);
           	   id = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + indexMinNew + "/points-of-interest/";
           	   response = sendPostRequestRawStr(id, jsonBody, "application/json");
           	   if(response.toString().contains("id")) {
           		   
           		String[] imageIDs = response.split("\"id\":");
           		String[] finalID = imageIDs[1].split(",");
           		allIDS.add(finalID[0]);
           	   }
           	   }
           imagePOI = allIDS.toString();
	   }
	   
       flag = 1;
	   allImage = allImage + imagePOI;
	   allProject = allProject + clusterIDs;
	   
 	  }//end big for
 	  	
 	   	  	
 	    if (flag == 1) {return "The POI(s) id for you message are: " + allImage.replace("[]", "").replace("]", ", ").replace("[", "") + "\nProject ID(s): " + allProject.replace("[]", "").replace("]", ", ").replace("[", "").replace(",", "");}
 	    else {return "The data was not send, so no POIs  were created";}
    }

    public static String queriesPOItext(String input) {
        Gson gson = new Gson();

        JsonElement json = gson.fromJson(input, JsonElement.class);
        JsonObject jobject = json.getAsJsonObject();


        JsonObject json_meta = new JsonObject();
        JsonObject  json_data = new JsonObject();
    	json_meta = jobject.getAsJsonObject("meta").getAsJsonObject("location");
    	
    	
    	 int flag = 0;
    	if (!json_meta.equals(new JsonObject()) ) {
        json_data = jobject.getAsJsonObject("data");
       
        for (int i = 0; i < json_data.getAsJsonArray("situations").size(); i++) {
        	
    	   String sourceText = "";
    	   sourceText = jobject.getAsJsonObject("meta").get("sourceText").toString();
    	   String user = "";
    	   user = jobject.getAsJsonObject("meta").get("entity").toString();
    	   
    	   String response = "";
    	   response = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/");
    	   
    	   String[] parts = response.split("\"id\":");
    	   
    	   String[] latitudeList = response.split("\"latitude\":");
    	   String[] longitudeList = response.split("\"longitude\":");
    	   
    	   List<String> ids = new ArrayList<String>();
    	   for(int j = 1; j< parts.length; j++){
    		   ids.add(parts[j].split(",\"status\"")[0].toString());
    		   }
           
    	   List<String> latitudeListFinal = new ArrayList<String>();
    	   for(int j = 1; j < latitudeList.length; j++){
    		   latitudeListFinal.add(latitudeList[j].split(",\"longitude\":")[0].toString());
    		   }
    	   
    	   List<String> longitudeListFinal = new ArrayList<String>();
    	   for(int j = 1; j < longitudeList.length; j++){
    		   longitudeListFinal.add(longitudeList[j].split("},\"")[0].toString());
    		   }
    	   
    	   String[] startingDate = response.split("\"start_date\":");
    	   List<String> startDate = new ArrayList<String>();
    	   for(int j = 1; j < startingDate.length; j++){
    		   startDate.add(startingDate[j].split(",")[0].replace("\"", "").replace("}", "").replace("]", "").replace("[", "").replace("\n", ""));
    		   }
    	   String[] endingDate = response.split("\"end_date\":");
    	   List<String> endDate = new ArrayList<String>();
    	   for(int j = 1; j < endingDate.length; j++){
    		   endDate.add(endingDate[j].split(",")[0].replace("\"", "").replace("}", "").replace("]", "").replace("]", "").replace("\n", ""));
    		   }
    	   
    	   //create json for new pois
    	   double longitude = 0.0;
           double latitude = 0.0;
           latitude = json_meta.get("coordinates").getAsJsonArray().get(0).getAsDouble();
           longitude = json_meta.get("coordinates").getAsJsonArray().get(1).getAsDouble();
           String categoryConst = json_data.get("category").toString().replace("\"", "");
           String subcategoryConst  = json_data.get("subcategory").toString().replace("\"", "");
           
           System.out.println(categoryConst);
           System.out.println(subcategoryConst);
           //end here code for new pois json
           
           //procedure to find project ids
    	   List<Double> longitudeSE = new ArrayList<Double>();
    	   for(int j = 1; j < longitudeListFinal.size();  j = j + 2){
    		   double helper = 0;
    		   helper = Float.valueOf(longitudeListFinal.get(j));
    		   longitudeSE.add(helper);
    		   }
    	   
    	   List<Double> longitudeNW = new ArrayList<Double>();
    	   for(int j = 0; j < longitudeListFinal.size();  j = j + 2){
    		   double helper = 0;
    		   helper = Float.valueOf(longitudeListFinal.get(j));
    		   longitudeNW.add(helper);
    		   }
    	   
    	   List<Double> latitudeSE = new ArrayList<Double>();
    	   for(int j = 1; j < latitudeListFinal.size();  j = j + 2){
    		   double helper = 0;
    		   helper = Float.valueOf(latitudeListFinal.get(j));
    		   latitudeSE.add(helper);
    		   }
    	   
    	   List<Double> latitudeNW = new ArrayList<Double>();
    	   for(int j = 0; j < latitudeListFinal.size();  j = j + 2){
    		   double helper = 0;
    		   helper = Float.valueOf(latitudeListFinal.get(j));
    		   latitudeNW.add(helper);
    		   } 
    	  
    	   LocalDate date = LocalDate.now();
           List<Integer> clusterIDs = new ArrayList<Integer>();
    	   for(int j = 0; j < longitudeSE.size(); j++) {
    		   double nwLat = 0;
    		   double seLat = 0;
    		   double nwLon = 0;
    		   double seLon = 0;
    		   nwLat = latitudeNW.get(j);
    		   seLat = latitudeSE.get(j);
    		   nwLon = longitudeNW.get(j);
    		   seLon = longitudeSE.get(j);

	//    	       if(Integer.parseInt(startDate.get(j).split("-")[0]) <= Integer.parseInt(date.toString().split("-")[0]) && Integer.parseInt(date.toString().split("-")[0]) <= Integer.parseInt(endDate.get(j).split("-")[0])) {
	//	    	   if(Integer.parseInt(startDate.get(j).split("-")[1]) <= Integer.parseInt(date.toString().split("-")[1]) && Integer.parseInt(date.toString().split("-")[1]) <= Integer.parseInt(endDate.get(j).split("-")[1])) {
	//	    		   if(Integer.parseInt(startDate.get(j).split("-")[2]) <= Integer.parseInt(date.toString().split("-")[2]) && Integer.parseInt(date.toString().split("-")[2]) <= Integer.parseInt(endDate.get(j).split("-")[2])) {
	//	    			   System.out.println(ids.get(j));
	//	    		   }
	//	    	   }
	//	       }
    	       	       
	          if( seLat <= latitude && latitude <= nwLat && nwLon <= longitude && longitude <= seLon ) {
	    		   clusterIDs.add(Integer.valueOf(ids.get(j)));

    		}
    	   }//for
    	   //end finding project ids
    	   
    	   //find pois based on project ids
    	   List<String> idsPOIS = new ArrayList<String>();
    	   List<String> categoryPOIS = new ArrayList<String>();
    	   List<String> subcategoryPOIS = new ArrayList<String>();
    	   List<String> latitudePOIS = new ArrayList<String>();
    	   List<String> longitudePOIS = new ArrayList<String>();
    	   System.out.println(clusterIDs.size());
    	   
    	   for (int t = 0; t < clusterIDs.size(); t++) {
    		 String poisResponse = "";
		     int indexMin = 0;
		     indexMin = clusterIDs.get(t);
		     poisResponse = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + indexMin + "/points-of-interest?current_user=%22" + user.replace("\"", "") + "%22&order=ASC&as_point=true");
		     
		     try{
		     String[] poisIDs = poisResponse.split("\"id\":");
		     
		     for(int j = 1; j< poisIDs.length; j++){
		    	 idsPOIS.add(indexMin + "-" + poisIDs[j].split(",\"category\"")[0].toString());
    		   }
		     
		     String[] poisCategory = poisResponse.split("\"category\":");
		     for(int j = 1; j< poisCategory.length; j++){
		    	 categoryPOIS.add(poisCategory[j].split(",\"subcategory\"")[0].toString());
    		   }

		     String[] poisSubcategory = poisResponse.split("\"subcategory\":");
		     for(int j = 1; j< poisSubcategory.length; j++){
		    	 subcategoryPOIS.add(poisSubcategory[j].split(",\"username\"")[0].toString());
    		   }
		     
		     String[] lonPOIS = poisResponse.split("\"coordinates\"");
		     for(int j = 1; j< lonPOIS.length; j++){
		    	 longitudePOIS.add(lonPOIS[j].split(",")[0].toString().replace(":[", ""));
    		   }
		     
		     String[] latPOIS = poisResponse.split("\"coordinates\"");
		     for(int j = 1; j< latPOIS.length; j++){
		    	 latitudePOIS.add(latPOIS[j].split(",")[1].toString().replace(":[", "").replace("]}}", "").replace("]", ""));
    		   }
		     }
		     catch(Exception e){
	               System.err.println(e.getCause());
	          }
		     }

    	   
    	   //Find the relative pois
           List<String> relativePOI = new ArrayList<String>();
    	   for(int j = 0; j < idsPOIS.size(); j++) {
    		   double lat = 0;
    		   double lon = 0;
    		   String category = "";
    		   String subcategory = "";
    		   lat = Double.parseDouble(latitudePOIS.get(j).replace("}", ""));
    		   lon = Double.parseDouble(longitudePOIS.get(j).replace("}", ""));
    		   category = categoryPOIS.get(j).replace("\"", "");
    		   subcategory = subcategoryPOIS.get(j).replace("\"", "");
    		   if (Math.abs(latitude - Math.abs(lat)) < 0.0005) {
    			   if (Math.abs(longitude - Math.abs(lon)) < 0.0005) {
    				   if (category.equals(categoryConst)) {
    					   if (subcategory.split(",name")[0].equals(subcategoryConst)) {
    						   relativePOI.add(idsPOIS.get(j));
    					   }
    				   }
    			   }
    		   }
    	   }
    	   
    	   String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
    	   
    	   
    	   for(int j = 0; j < clusterIDs.size(); j++) {
    	   //some code for the creation of DSS information
           JSONObject jsonDSS = new JSONObject();
           jsonDSS.put("type", "Textual");
           jsonDSS.put("id", clusterIDs.get(j).toString().replace("\"", ""));
           jsonDSS.put("category", categoryConst);
           jsonDSS.put("subcategory", subcategoryConst);
           jsonDSS.put("location", json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("label").toString().replace("\"", ""));
           JSONArray coordinatesArrDSS = new JSONArray();
           coordinatesArrDSS.put(longitude);
           coordinatesArrDSS.put(latitude);
           jsonDSS.put("geometry",coordinatesArrDSS);
           JSONArray allAffected = new JSONArray();
           ArrayList<String> listsvd_ids = new ArrayList<String>();  
           for (int k=0;k < json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().size();k++){ 

	           JSONObject affected = new JSONObject();
	           
	           affected.put("Class", json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().get(k).getAsJsonObject().get("name").toString().replace("\"", ""));
	           affected.put("No", json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().get(k).getAsJsonObject().get("quantity").toString().replace("\"", ""));
	           allAffected.put(affected);
    	   }
    	   jsonDSS.put("affected_objects", allAffected);
    	   
    	   
	    	   ////new code severity score//////
		        JSONObject objectDSSDanger = new JSONObject();
		        try{
		       	   String responseDanger = "";
		          	   responseDanger = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + clusterIDs.get(j).toString().replace("\"", "") + "/danger-zones");
		          	   System.out.println(responseDanger);
		          	   JsonElement jsonDanger = gson.fromJson(responseDanger, JsonElement.class);
		           	   for (int o=0; o < jsonDanger.getAsJsonArray().size();o++) {
		           		   JsonObject danger = jsonDanger.getAsJsonArray().get(o).getAsJsonObject();
		    	   		   double nwLatDanger = danger.get("location_nw").getAsJsonObject().get("latitude").getAsDouble();
		    	   		   double seLatDanger = danger.get("location_se").getAsJsonObject().get("latitude").getAsDouble();
		    	   		   double nwLonDanger = danger.get("location_nw").getAsJsonObject().get("longitude").getAsDouble();
		    	   		   double seLonDanger = danger.get("location_se").getAsJsonObject().get("longitude").getAsDouble();
		    	   		   if( seLatDanger <= latitude && latitude <= nwLatDanger && nwLonDanger <= longitude && longitude <= seLonDanger ) {
		    	   			   if (danger.get("description").toString().contains(":")) {
		    		   			   objectDSSDanger.put("severity", danger.get("description").toString().replace("\"", "").split(": ")[1]);
		    		   			   }
		    		   		   else {
		    		   				objectDSSDanger.put("severity", danger.get("description").toString().replace("\"", ""));
		    		   		   }
		    	   			   objectDSSDanger.put("created_at", danger.get("created_at").toString().replace("\"", ""));
		    	   			   objectDSSDanger.put("id", clusterIDs.get(j).toString().replace("\"", ""));;
		    	   			   objectDSSDanger.put("latitude", latitude);
		    	   			   objectDSSDanger.put("longitude", longitude);
		    	   			}
		           	   }
		   	    } catch(Exception e){
		   	        System.err.println(e.getCause());
		   	    }
	   	   JSONArray objectsDanger = new JSONArray();
	   	   jsonDSS.put("dangerInfo", objectDSSDanger);
		       System.out.println(jsonDSS);
	   	   ////new code severity score////
           
  
		   if (jsonDSS.has("id") ) {
    	   try{
    		   
    		   ConnectionString connectionString = new ConnectionString("mongodb://xr4d_dss_user:x38vC&26@160.40.53.24:27017/?authSource=XR4D_DSS");
        	   MongoClientSettings settings = MongoClientSettings.builder()
        	           .applyConnectionString(connectionString)
        	           .build();
        	   MongoClient mongoClient = MongoClients.create(settings);
        	   MongoDatabase database = mongoClient.getDatabase("XR4D_DSS");
        	   MongoCollection<Document> toys = database.getCollection("cappedCollection");
        	   Document doc = Document.parse(jsonDSS.toString());
        	   toys.insertOne(doc);
      
        	   
        	   LoggerContext loggerContext = (LoggerContext) LoggerFactory.getILoggerFactory();
        	   Logger rootLogger = loggerContext.getLogger("org.mongodb.driver");
        	   rootLogger.setLevel(Level.OFF);
        	   mongoClient.close();
        	 
       
           } catch(Exception e){
               System.err.println(e.getCause());
           }
		   }
    	   }
    	   //ends find relative pois
    	   
    	   //some block code to do the text generation procedure  
    	   String titleGeneration = "";
    	   String descriptionGeneration = "";
    	   List<String> descriptionsPOI = new ArrayList<String>();

    		  
       	   	for (int k = 0; k < relativePOI.size(); k++) {
       	   		JSONArray jsonOuterWrapperVisual = new JSONArray();
         	   try {
    	   		JSONObject jsonMetaVisual = new JSONObject();
    	   		JSONObject innerDataVisual = new JSONObject();
    	   		JSONArray outerDataVisual = new JSONArray();
    	   		JSONObject jsonInnerWrapperVisual = new JSONObject();
    	   		
    	   		JSONArray dummyVisual = new JSONArray();
    	   		String poisGeneration = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + relativePOI.get(k).split("-")[0] + "/points-of-interest/" + relativePOI.get(k).split("-")[1] + "?current_user=%22" + user.replace("\"", "") + "%22&order=ASC&as_point=true");
    	   		Gson gsonNew = new Gson();
    	        JsonElement jsonNew = gsonNew.fromJson(poisGeneration, JsonElement.class);
    	        JsonObject jobjectNew = jsonNew.getAsJsonObject();
    	        jsonMetaVisual.put("sender", JSONObject.NULL);
    	        jsonMetaVisual.put("entity", jobject.getAsJsonObject("meta").get("project_id").toString().replace("\"", ""));
    	        jsonMetaVisual.put("project_id", jobject.getAsJsonObject("meta").get("project_id").toString().replace("\"", ""));
    	        jsonMetaVisual.put("timestamp", "2022-03-10T09:58:15.867Z");
    	        jsonMetaVisual.put("simmoid", JSONObject.NULL);
    	        
    	        innerDataVisual.put("shotIdx", 0);
    	        innerDataVisual.put("startFrame", 0);
    	        innerDataVisual.put("endFrame", 0);
    	        innerDataVisual.put("peopleInDanger", Float.parseFloat(jobjectNew.get("attributes").getAsJsonObject().get("peopleInDanger").toString().replace("\"", "")));
    	        innerDataVisual.put("animalsInDanger", Float.parseFloat(jobjectNew.get("attributes").getAsJsonObject().get("animalsInDanger").toString().replace("\"", "")));
    	        innerDataVisual.put("vehiclesInDanger", Float.parseFloat(jobjectNew.get("attributes").getAsJsonObject().get("vehiclesInDanger").toString().replace("\"", "")));
    	        innerDataVisual.put("area", jobjectNew.get("attributes").getAsJsonObject().get("area").toString().replace("\"", ""));
    	        innerDataVisual.put("areaProb", 0);
    	        innerDataVisual.put("outdoor", jobjectNew.get("attributes").getAsJsonObject().get("outdoor").toString().replace("\"", ""));
    	        innerDataVisual.put("riverOvertop", jobjectNew.get("attributes").getAsJsonObject().get("riverOvertop").toString().replace("\"", ""));
    	        innerDataVisual.put("emergencyProb", 0);
    	        innerDataVisual.put("emergencyType", jobjectNew.get("attributes").getAsJsonObject().get("emergencyType").toString().replace("\"", ""));
    	        //innerDataVisual.put("objectsFound", jobjectNew.get("attributes").getAsJsonObject().get("objectsInDanger").toString().replace("\"", ""));
    	        innerDataVisual.put("objectsFound", dummyVisual);
    	        
    	        outerDataVisual.put(innerDataVisual);
    	        jsonInnerWrapperVisual.put("meta", jsonMetaVisual);
    	        jsonInnerWrapperVisual.put("data", outerDataVisual);
    	        jsonOuterWrapperVisual.put(jsonInnerWrapperVisual);
      	   		} catch(Exception e){
                    System.err.println(e.getCause());
                	}
    	        JSONArray jsonTextLabel = new JSONArray();
    	        JSONArray jsonVisualLabel = new JSONArray();
    	        JSONObject jsonInnerGeneration = new JSONObject();
    	        JSONArray projectJson = new JSONArray();
    	        JSONObject jsonHeaderGeneration = new JSONObject();
    	        JSONObject jsonFinalGeneration = new JSONObject();
	    	 
		    	 //json for meta//
	             JSONObject metaGeneration = new JSONObject();
	             JSONObject locationGeneration = new JSONObject();
	             metaGeneration.put("id", jobject.getAsJsonObject("meta").get("id").toString().replace("\"", ""));
	             metaGeneration.put("sourceText",  jobject.getAsJsonObject("meta").get("sourceText").toString().replace("\"", ""));
	             metaGeneration.put("sourceType",  jobject.getAsJsonObject("meta").get("sourceType").toString().replace("\"", ""));
	             metaGeneration.put("project_id",  jobject.getAsJsonObject("meta").get("project_id").toString().replace("\"", ""));
	             metaGeneration.put("entity",  jobject.getAsJsonObject("meta").get("entity").toString().replace("\"", ""));
	             JSONArray coordinatesGeneration = new JSONArray();
	             coordinatesGeneration.put(jobject.getAsJsonObject("meta").getAsJsonObject("location").getAsJsonArray("coordinates").get(0).getAsDouble());
	             coordinatesGeneration.put(jobject.getAsJsonObject("meta").getAsJsonObject("location").getAsJsonArray("coordinates").get(1).getAsDouble());
	             locationGeneration.put("coordinates", coordinatesGeneration);
	             locationGeneration.put("radius", jobject.getAsJsonObject("meta").getAsJsonObject("location").get("radius").getAsDouble());
	             locationGeneration.put("inferred", jobject.getAsJsonObject("meta").getAsJsonObject("location").get("inferred").getAsString().replace("\"", ""));
	             metaGeneration.put("location", locationGeneration);
		    	 //end json for meta//
	             
	             //json for data//
	             JSONObject dataGeneration = new JSONObject();
	             JSONObject situationGeneration = new JSONObject();
	             dataGeneration.put("type", jobject.getAsJsonObject("data").get("type").toString().replace("\"", ""));
	             dataGeneration.put("category",  jobject.getAsJsonObject("data").get("category").toString().replace("\"", ""));
	             dataGeneration.put("subcategory",  jobject.getAsJsonObject("data").get("subcategory").toString().replace("\"", ""));
	
	             ArrayList<String> affectedGeneration = new ArrayList<String>();
	             for (int j = 0; j < jobject.getAsJsonObject("data").get("situations").getAsJsonArray().get(0).getAsJsonObject().get("affected_objects").getAsJsonArray().size(); j++) {
	            	 
	            	 affectedGeneration.add(jobject.getAsJsonObject("data").get("situations").getAsJsonArray().get(0).getAsJsonObject().get("affected_objects").getAsJsonArray().get(j).getAsJsonObject().get("name").toString().replace("\"", ""));
	            	 
	             }
	             
	             situationGeneration.put("affected_objects", affectedGeneration);
	             situationGeneration.put("label", jobject.getAsJsonObject("data").get("situations").getAsJsonArray().get(0).getAsJsonObject().get("label").toString().replace("\"", ""));
	             JSONArray situations = new JSONArray();
	             situations.put(situationGeneration);
	             dataGeneration.put("situations", situations);
	             //end json for data//
	             
	             //final json//
	             JSONObject textPart = new JSONObject();
	             textPart.put("data", dataGeneration);
	             textPart.put("meta", metaGeneration);
	             
		    	 jsonTextLabel.put(textPart);
		    	 jsonInnerGeneration.put("project_id", jobject.getAsJsonObject("meta").get("project_id").toString().replace("\"", ""));
		    	 
		    	 jsonInnerGeneration.put("text", jsonTextLabel);
		    	 jsonInnerGeneration.put("visual", jsonOuterWrapperVisual);
		    	 jsonInnerGeneration.put("stress_lvl", JSONObject.NULL);
		    	 projectJson.put(jsonInnerGeneration);
		    	 jsonHeaderGeneration.put("project", projectJson);
		    	 jsonHeaderGeneration.put("created_at", "2022-03-24T13:59:49.063Z");
		    	 jsonHeaderGeneration.put("id", jobject.getAsJsonObject("meta").get("id").toString().replace("\"", ""));
		    	 jsonHeaderGeneration.put("first_timestamp", "2022-03-10T09:58:15.867Z");
		    	 jsonHeaderGeneration.put("last_timestamp", "2022-03-23T19:58:15.867Z");
		    	 jsonFinalGeneration.put("header", jsonHeaderGeneration);
		    	 System.out.println("\n\n\nGeneration Json: " + jsonFinalGeneration + "\n\n\n");
		    	 //end final json//
	    	 
	    		 String idGeneration = "";
	    		 idGeneration = "https://xr4drama.upf.edu/xr4drama-services/api/nlg/generatePOI";
	           	 response = sendPostRequestRawStr(idGeneration, jsonFinalGeneration.toString(), "application/json");
	           	 JsonElement jsonTG = gson.fromJson(response, JsonElement.class);
	           	 JsonObject helperTG = jsonTG.getAsJsonObject();
	             System.out.println(helperTG.get("data").getAsJsonObject().get("description").toString());
	             System.out.println(helperTG.get("data").getAsJsonObject().get("title").toString());
	             
	      	    titleGeneration = helperTG.get("data").getAsJsonObject().get("title").toString();
	      	    descriptionGeneration = helperTG.get("data").getAsJsonObject().get("description").toString();
	      	    descriptionsPOI.add(titleGeneration + "000" + descriptionGeneration + "000" + relativePOI.get(k).split("-")[1]);
       	   	}
          	 
          
    	   //
    	   
    	   
    	   
    	   
    	   System.out.println("The final results for descriptions: " + descriptionsPOI);
    	   //relativePOI.clear();
    	   if (relativePOI.size() > 0) {
    		   //update pois

          for (int j = 0; j < relativePOI.size(); j++) {//change this later to relativePOI list
	           JSONObject attributeInstance = new JSONObject();
	           JSONObject attribute = new JSONObject();
	           attribute.put("label", json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("label").toString().replace("\"", ""));
	           
	           ArrayList<String> affectedPOI = new ArrayList<String>();
	           for (int k = 0; k < json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().size(); k ++) {
	        	   affectedPOI.add(json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().get(k).getAsJsonObject().get("name").toString().replace("\"", "") + "-" +json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().get(k).getAsJsonObject().get("quantity").toString().replace("\"", ""));
	           }
	           attribute.put("affected_objects", affectedPOI.toString());
	           
	           String descriptionFinal = "";
	           String titleFinal = "";
	           for (int t=0; t < descriptionsPOI.size(); t++) {
	        	    if (relativePOI.get(j).split("-")[1].toString().equals(descriptionsPOI.get(t).toString().replace("\"", "").split("000")[2].toString())){
	        	    	descriptionFinal = descriptionsPOI.get(t).toString().replace("\"", "").split("000")[1].toString();
	        	    	titleFinal = descriptionsPOI.get(t).toString().replace("\"", "").split("000")[0].toString();
	        	    }
	           }
	           if (descriptionFinal.equals("")) {
	        	   attributeInstance.put("description", sourceText.toString().replace("\"", "").replace("\\n", "\n"));
	           }
	           else{
	        	   attributeInstance.put("description", descriptionFinal.replace("\"", "").replace("\\n", "\n"));
	           }
	           if (titleFinal.equals("")) {
	        	   attributeInstance.put("name", "");
	           }
	           else{
	        	   attributeInstance.put("name", titleFinal.replace("\"", "").replace("\\n", "\n"));
	           }
	           attributeInstance.put("attributes", attribute);
	           attributeInstance.put("category",categoryConst);
	           attributeInstance.put("subcategory", subcategoryConst);
			   String idPOI = "";
			   System.out.println(attributeInstance);
			   idPOI = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + relativePOI.get(j).split("-")[0].toString() + "/points-of-interest/" + relativePOI.get(j).split("-")[1].toString() + "?current_user=" + user.replace("\"", "");
			   System.out.println(idPOI);
			   String answerUpdate = sendPutRequestRawStr(idPOI, attributeInstance.toString(), "application/json");
			   //all attributes can be created
			   if (answerUpdate.contains("404")) {
				   JSONObject descriptionPOI = new JSONObject();
				   JSONObject labelPOI = new JSONObject();
				   JSONObject affectedPOIUpdate = new JSONObject();
				   descriptionPOI.put("description", descriptionGeneration.replace("\"", "").replace("\\n", "\n"));
				   labelPOI.put("label", affectedPOI.toString());
				   affectedPOIUpdate.put("affected_objects", json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("label").toString().replace("\"", ""));
				   idPOI = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + relativePOI.get(j).split("-")[0].toString() + "/points-of-interest/" + relativePOI.get(j).split("-")[1].toString() + "/attributes?current_user=" + user.replace("\"", "");
				   sendPostRequestRawStr(idPOI, labelPOI.toString(), "application/json");
				   sendPostRequestRawStr(idPOI, affectedPOIUpdate.toString(), "application/json");
			   }
    		   }
    	   }
    	   else {//create new pois
    		   //code for updating a poi
    		   
	           JSONObject jsonObject = new JSONObject();
	           JSONObject attributeObject = new JSONObject();
	           jsonObject.put("category",categoryConst);
	           jsonObject.put("subcategory", subcategoryConst);
	           jsonObject.put("name", "Citizen generated POI " + timeStamp);
	           attributeObject.put("label", json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("label").toString().replace("\"", ""));
	           //attributeObject.put("affected_objects", json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").toString().replace("\"", ""));
	           ArrayList<String> affectedPOI = new ArrayList<String>();
	           for (int k = 0; k < json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().size(); k ++) {
	        	   affectedPOI.add(json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().get(k).getAsJsonObject().get("name").toString().replace("\"", "") + "-" +json_data.getAsJsonArray("situations").get(i).getAsJsonObject().get("affected_objects").getAsJsonArray().get(k).getAsJsonObject().get("quantity").toString().replace("\"", ""));
	           }
	           attributeObject.put("affected_objects", affectedPOI.toString());
	           
	           String descriptionFinal = descriptionsPOI.get(0).toString().replace("\"", "").split("000")[1].toString();
	           String titleFinal = descriptionsPOI.get(1).toString().replace("\"", "").split("000")[0].toString();
	           
	           if (descriptionFinal.equals("")) {
	        	   jsonObject.put("description", sourceText.toString().replace("\"", "").replace("\\n", "\n"));
	           }
	           else{
	        	   jsonObject.put("description", descriptionFinal.replace("\"", "").replace("\\n", "\n"));
	           }
	           if (titleFinal.equals("")) {
	        	   jsonObject.put("name", "");
	           }
	           else{
	        	   jsonObject.put("name", titleFinal.replace("\"", "").replace("\\n", "\n"));
	           }
	           
	           jsonObject.put("current_user", user.replace("\"", "").replace("\\n", "\n"));
	           JSONObject geometryObject = new JSONObject();
	           geometryObject.put("type","Point");
	           JSONArray coordinatesArr = new JSONArray();
	           coordinatesArr.put(longitude);//the above are the theoretically correct commands
	           coordinatesArr.put(latitude);
           
	           geometryObject.put("coordinates",coordinatesArr);
	           jsonObject.put("geometry",geometryObject);
	           
	           jsonObject.put("attributes",attributeObject);
	           
	           String jsonBody = jsonObject.toString();
	           for (int t = 0; t < clusterIDs.size(); t++) {
	        	   String id = "";
	           	   int indexMinNew = 0;
	           	   indexMinNew = clusterIDs.get(t);
	           	   id = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + indexMinNew + "/points-of-interest/";
	           	   sendPostRequestRawStr(id, jsonBody, "application/json");
	           	   }
    	   }
		   
           flag = 1;
           
       }}
      else {return "The instance did not contain location information";}
    	
    if (flag == 1) {return "The data was send";}
    else {return "The data was not send";}
    }
    
    public static String queriesDSS(String input)
    {   Gson gson = new Gson();
        //code to create and send the json to the DSS
        JsonElement json = gson.fromJson(input, JsonElement.class);
        JsonObject jobject = json.getAsJsonObject();
        //System.out.println(jobject);
        
        for (int i =0; i < jobject.getAsJsonArray("data").size(); i++) {
        for (int l =0; l < jobject.getAsJsonArray("data").get(i).getAsJsonArray().size(); l++) {
            double latitude = jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("latitude").getAsDouble();
            double longitude = jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("longitude").getAsDouble();
   
           String response = "";
           response = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/");
           System.out.println(response);
           String[] parts = response.split("\"id\":");
           String[] latitudeList = response.split("\"latitude\":");
           String[] longitudeList = response.split("\"longitude\":");
           
           List<String> ids = new ArrayList<String>();
           for(int j = 1; j< parts.length; j++){
               ids.add(parts[j].split(",\"status\"")[0].toString());
               }
              
           List<String> latitudeListFinal = new ArrayList<String>();
           for(int j = 1; j < latitudeList.length; j++){
               latitudeListFinal.add(latitudeList[j].split(",\"longitude\":")[0].toString());
               }
           
           List<String> longitudeListFinal = new ArrayList<String>();
           for(int j = 1; j < longitudeList.length; j++){
               longitudeListFinal.add(longitudeList[j].split("},\"")[0].toString());
               }

            
           //procedure to find project ids
           List<Double> longitudeSE = new ArrayList<Double>();
           for(int j = 1; j < longitudeListFinal.size();  j = j + 2){
               double helper = 0;
               helper = Float.valueOf(longitudeListFinal.get(j));
               longitudeSE.add(helper);
               }
           
           List<Double> longitudeNW = new ArrayList<Double>();
           for(int j = 0; j < longitudeListFinal.size();  j = j + 2){
               double helper = 0;
               helper = Float.valueOf(longitudeListFinal.get(j));
               longitudeNW.add(helper);
               }
           
           List<Double> latitudeSE = new ArrayList<Double>();
           for(int j = 1; j < latitudeListFinal.size();  j = j + 2){
               double helper = 0;
               helper = Float.valueOf(latitudeListFinal.get(j));
               latitudeSE.add(helper);
               }
           
           List<Double> latitudeNW = new ArrayList<Double>();
           for(int j = 0; j < latitudeListFinal.size();  j = j + 2){
               double helper = 0;
               helper = Float.valueOf(latitudeListFinal.get(j));
               latitudeNW.add(helper);
               } 
          
              
           List<Integer> clusterIDs = new ArrayList<Integer>();
           for(int j = 0; j < longitudeSE.size(); j++) {
               double nwLat = 0;
               double seLat = 0;
               double nwLon = 0;
               double seLon = 0;
               nwLat = latitudeNW.get(j);
               seLat = latitudeSE.get(j);
               nwLon = longitudeNW.get(j);
               seLon = longitudeSE.get(j);
               //System.out.println(seLat);
               //System.out.println(latitude);
               //System.out.println(nwLat);
               //System.out.println("//////////////////////");
               //System.out.println(nwLon);
               //System.out.println(longitude);
               //System.out.println(seLon);
               //System.out.println("/////////NEW//////////");
               if( seLat <= latitude && latitude <= nwLat && nwLon <= longitude && longitude <= seLon ) {
                   clusterIDs.add(Integer.valueOf(ids.get(j)));
                }
           }//for
           //end finding project ids
           System.out.println("Number of Projects: " + clusterIDs.size());
           
           List<String> latitudePOIS = new ArrayList<String>();
           List<String> longitudePOIS = new ArrayList<String>();
           List<String> idsPOIS = new ArrayList<String>();
           List<String> attachedPOIS = new ArrayList<String>();
           List<String> tasksIDs = new ArrayList<String>();
           //start finding related pois
           if (clusterIDs.size() > 0) {
            for (int p=0; p < clusterIDs.size(); p++) {
                String poisResponse = "";
                System.out.println("Project: " + clusterIDs.get(p));
                int helperIndex = 0;
                helperIndex = clusterIDs.get(p);
                poisResponse = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + helperIndex + "/points-of-interest?current_user=%22KB%22&order=ASC&as_point=true");
                String attachedResponse = sendGetRequestStr("https://geoservice.xr4drama.up2metric.com:8001/projects/" + clusterIDs.get(p) + "/tasks");
                System.out.println(attachedResponse);
                String[] attachedIDS = attachedResponse.split("\"attached_poi\"");
                for(int j = 1; j< attachedIDS.length; j++){
                	attachedPOIS.add(attachedIDS[j].replace(":{\"id\":", "").split(",")[0]);
              }
                String[] tasks = attachedResponse.split("\"id\":");
                
                for(int j = 1; j< tasks.length; j++){
                	if(tasks[j].contains(",\"headline\":")) {
                		tasksIDs.add(tasks[j].split(",\"headline\":")[0]);
                	}
              }
                //here I need some changes based on the user
             try{
                 String[] poisIDs = poisResponse.split("\"id\":");
                 
                 for(int j = 1; j< poisIDs.length; j++){
                     idsPOIS.add(helperIndex + "-" + poisIDs[j].split(",\"category\"")[0].toString());
               }
                 
                 
                 String[] lonPOIS = poisResponse.split("\"coordinates\"");
                 for(int j = 1; j< lonPOIS.length; j++){
                     longitudePOIS.add(lonPOIS[j].split(",")[0].toString().replace(":[", ""));
               }
                 
                 String[] latPOIS = poisResponse.split("\"coordinates\"");
                 for(int j = 1; j< latPOIS.length; j++){
                     latitudePOIS.add(latPOIS[j].split(",")[1].toString().replace(":[", "").replace("]}}", "").replace("]", ""));
               }
                 }
                 catch(Exception e){
                       System.err.println(e.getCause());
                  }
             

           List<String> relativePOI = new ArrayList<String>();
           for(int j = 0; j < idsPOIS.size(); j++) {
               double lat = 0;
               double lon = 0;
               String category = "";
               String subcategory = "";
               lat = Double.parseDouble(latitudePOIS.get(j).replace("}", ""));
               lon = Double.parseDouble(longitudePOIS.get(j).replace("}", ""));
               if (Math.abs(latitude) == Math.abs(lat)) {
                   if (Math.abs(longitude) == Math.abs(lon)) {
                       relativePOI.add(idsPOIS.get(j));   
                   }
               }
           }
           
           
           Set<String> set = new HashSet<String>(attachedPOIS);
           attachedPOIS.clear();
           attachedPOIS.addAll(set);
           Set<String> setTask = new HashSet<String>(tasksIDs);
           tasksIDs.clear();
           tasksIDs.addAll(setTask);
           
           System.out.println("Number of relative POIs: " + relativePOI);
           //relativePOI.clear();
           if (relativePOI.size() > 0) {
	           for (int t=0; t<relativePOI.size(); t++) {        	   
	               JSONObject jsonDSS = new JSONObject();
	               jsonDSS.put("type","editPOI");
	               jsonDSS.put("attached_poi_id", relativePOI.get(t).split("-")[1]);
	               jsonDSS.put("headline", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("name").toString().replace("\"", ""));
	               jsonDSS.put("criticity", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("criticity").toString().replace("\"", ""));
	               jsonDSS.put("description", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("action").toString().replace("\"", ""));
	               jsonDSS.put("creator", "DSS");//it may need changes
	               jsonDSS.put("worker", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("responsibility").toString().replace("\"", ""));//it may need changes
	               String id = "";
	               id = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + relativePOI.get(t).split("-")[0].replace("\"", "") + "/tasks";
	               String jsonBody = jsonDSS.toString();
	               
	               sendPostRequestRawStr(id, jsonBody, "application/json"); 
	           }
           }
           else {
        	   String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
	           JSONObject jsonObject = new JSONObject();
	           JSONObject attributeObject = new JSONObject();
	           jsonObject.put("category", "Disaster Management");
	           jsonObject.put("subcategory", "Civil Protection Distribution Places");
	           jsonObject.put("name", "Citizen generated POI " + timeStamp);
	           attributeObject.put("label", "Null POI for task creation");
	           ArrayList<String> affectedPOI = new ArrayList<String>();
	           attributeObject.put("affected_objects", affectedPOI.toString());
        	   jsonObject.put("description", "");
        	   jsonObject.put("name", "");

	           
	           jsonObject.put("current_user", "citizen");
	           JSONObject geometryObject = new JSONObject();
	           geometryObject.put("type","Point");
	           JSONArray coordinatesArr = new JSONArray();
	           coordinatesArr.put(longitude);//the above are the theoretically correct commands
	           coordinatesArr.put(latitude);
           
	           geometryObject.put("coordinates",coordinatesArr);
	           jsonObject.put("geometry",geometryObject);
	           
	           jsonObject.put("attributes",attributeObject);
	           String jsonBody = jsonObject.toString();
	           for (int t = 0; t < clusterIDs.size(); t++) {
	        	   String id = "";
	           	   int indexMinNew = 0;
	           	   indexMinNew = clusterIDs.get(t);
	           	   id = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + indexMinNew + "/points-of-interest/";
	           	   String taskReturn = sendPostRequestRawStr(id, jsonBody, "application/json");
	           	   String desiredID = taskReturn.split(",\"category\"")[0].replace("{\"id\":", "").replace(" ", "");
	               JSONObject jsonDSS = new JSONObject();
	               jsonDSS.put("type","editPOI");
	               jsonDSS.put("attached_poi_id", desiredID);
	               jsonDSS.put("headline", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("name").toString().replace("\"", ""));
	               jsonDSS.put("criticity", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("criticity").toString().replace("\"", ""));
	               jsonDSS.put("description", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("action").toString().replace("\"", ""));
	               jsonDSS.put("creator", "DSS");//it may need changes
	               jsonDSS.put("worker", jobject.getAsJsonArray("data").get(i).getAsJsonArray().get(l).getAsJsonObject().get("responsibility").toString().replace("\"", ""));//it may need changes
	               
	               String idDSS = "https://geoservice.xr4drama.up2metric.com:8001/projects/" + indexMinNew + "/tasks";
	               String jsonBodyDSS = jsonDSS.toString();
	               
	               sendPostRequestRawStr(idDSS, jsonBodyDSS, "application/json"); 
	           	   }
	           
           }
           
          }
         }
//           //end finding related pois
 
        }
        }//end double for
        return "The data was send";
    }


}